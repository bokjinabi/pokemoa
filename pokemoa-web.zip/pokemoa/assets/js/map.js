/* =========================================================================
 * 포켓몬카드모아 — 실제 지도 엔진 (카카오맵 JavaScript SDK + 카카오 장소 검색)
 *
 * · 지도 타일: 카카오맵 JavaScript SDK (라이트·저채도 느낌은 카카오 기본 스타일 그대로)
 * · 주변 매장: 카카오 장소 검색(Places) — 편의점 카테고리(CS2) 병렬 조회 +
 *   결과에 없는 브랜드는 브랜드별 키워드 검색으로 보충한다(편의점 4사만:
 *   GS25·CU·세븐일레븐·이마트24). 해외 Overpass API 왕복이 없어 1초 안팎에 끝난다.
 *   카카오 장소 검색은 한 번에 최대 45건이라, 3km 이하는 중심 1곳에서 3페이지를,
 *   5km·20km는 중심 + 방위 오프셋 격자로 여러 번 나눠 조회해 외곽 매장까지 받는다.
 * · 동네·역 이름 검색도 카카오 장소 검색(keywordSearch)으로 즉시 조회한다.
 * · 매장 마커는 둥근 핀 대신 상태가 바로 읽히는 말풍선(알약) 마커
 *   (kakao.maps.CustomOverlay): 재고 있음 = 브랜드 색 말풍선(`CU · 입고 2종`),
 *   확인/없음 = 화이트·그레이 알약. 매장마다 보유·취급 카드 상품명을 함께 표시한다.
 * · 실시간 조회가 끝나지 않거나 응답 제한(쿼터·차단)이면 내장된 실제 좌표
 *   스냅샷으로 부드럽게 대체하고 배지에 상태를 표기한다. 카카오 SDK는 등록된
 *   도메인(https://moa-kr.github.io)에서만 지도를 그리므로, 그 밖의 주소
 *   (file://·미등록 프리뷰)에서는 안내 문구와 함께 스냅샷 목록으로 동작한다.
 * · 재고 상태는 편의점 앱 API 미연동 → 제보·샘플 기반임을 화면에서 밝힌다.
 * ========================================================================= */
window.PokeMoaMap = (function () {
  "use strict";

  var D = window.POKEMOA_DATA;
  /* 카카오디벨로퍼스 앱 `포켓몬카드모아`(ID 1655851) JavaScript 키.
     JS SDK 도메인에 https://moa-kr.github.io 가 등록되어 있다. */
  var KAKAO_KEY = "63b35e228dacdcc4d0e31f83a7738f22";
  var KAKAO_SDK = "https://dapi.kakao.com/v2/maps/sdk.js?appkey=" + KAKAO_KEY +
    "&libraries=services&autoload=false";
  var SDK_TIMEOUT = 9000;        /* SDK·지도 초기화를 이 시간까지 기다린다 */
  var SEARCH_TIMEOUT = 8000;     /* 다점 격자 조회가 늦으면 내장 좌표로 먼저 표시 */
  var MAX_MARKERS = 90;          /* 1km·3km */
  var MAX_MARKERS_5 = 120;       /* 5km — 격자 조회로 받은 외곽 매장까지 넉넉히 */
  var MAX_MARKERS_20 = 200;      /* 20km — 반경 전역(포항 남구·양덕·유강·오천 등) */
  /* 5km·20km 격자 조회의 방위(도, 북=0·동=90) */
  var DIRS4 = [0, 90, 180, 270];
  var DIRS8 = [0, 45, 90, 135, 180, 225, 270, 315];
  var BRAND_QUERY = { gs25: "GS25", cu: "CU", seven: "세븐일레븐", emart24: "이마트24" };
  var BRAND_ORDER_LIST = ["gs25", "cu", "seven", "emart24"];

  /* 도심(allow20:false) 지역 좌표 — 내 위치가 이 근처면 20km를 막는다 */
  function metroRegions() {
    return D.regions.filter(function (r) { return r.allow20 === false; });
  }
  var METRO_RADIUS_M = 12000;   /* 내 위치가 대도시 도심 반경 12km 안이면 도심으로 본다 */

  var st = {
    map: null,
    ready: false,
    sdkError: false,
    layer: [],        /* 현재 지도에 올린 CustomOverlay 목록 */
    ring: null,
    meMarker: null,
    markers: {},      /* id -> { ov, node } */
    all: [],          /* 현재 중심 기준 조회 결과(반경 밖 포함) */
    visible: [],
    brand: "all",
    product: "all",
    stockOnly: false,
    compact: false,
    cluster: false,
    radius: 3000,
    regionId: "pohang-north",
    origin: "region",  /* region | geo | search */
    center: null,
    source: "snapshot",/* live | snapshot */
    fetchedAt: null,
    loading: { tiles: true, data: true },
    selectedId: null,
    seq: 0,
    geoBusy: false,
    lastError: null,
    fetchedRadius: 0,
    fetchedBand: "",   /* 마지막으로 조회한 반경 구분(3 / 5 / 20) */
    snapshotLabel: "",
    pendingLive: false,
    badgeWasSnapshot: false,
    metro: false,
    allow20: true,
    relay: null,        /* 집 태블릿 중계에서 받은 실재고 요약 { ok, sources, at, count } */
    relayAt: ""
  };

  var el = {};

  /* ------------------------------------------------------------- 유틸 */
  function emit(name, detail) {
    document.dispatchEvent(new CustomEvent(name, { detail: detail || {} }));
  }

  function region(id) {
    for (var i = 0; i < D.regions.length; i++) if (D.regions[i].id === id) return D.regions[i];
    return D.regions[0];
  }

  function meters(a, b) {
    var R = 6371008.8;
    var dLat = (b.lat - a.lat) * Math.PI / 180;
    var dLng = (b.lng - a.lng) * Math.PI / 180;
    var la1 = a.lat * Math.PI / 180;
    var la2 = b.lat * Math.PI / 180;
    var h = Math.sin(dLat / 2) * Math.sin(dLat / 2) +
      Math.cos(la1) * Math.cos(la2) * Math.sin(dLng / 2) * Math.sin(dLng / 2);
    return 2 * R * Math.asin(Math.min(1, Math.sqrt(h)));
  }

  /* 중심에서 dist(m) 떨어진 방위각(도, 북=0·동=90) 좌표 */
  function offsetPoint(center, dist, angleDeg) {
    var R = 6371008.8;
    var a = angleDeg * Math.PI / 180;
    var dLat = (dist * Math.cos(a)) / R * 180 / Math.PI;
    var dLng = (dist * Math.sin(a)) / (R * Math.cos(center.lat * Math.PI / 180)) * 180 / Math.PI;
    return { lat: center.lat + dLat, lng: center.lng + dLng };
  }

  /* 고리 위 방위 지점들 — 중심에서 dist(m) 떨어진 곳을 ringRadius(m)로 pages페이지씩 */
  function pushRing(pts, center, dist, ringRadius, pages, dirs) {
    dirs.forEach(function (a) {
      var o = offsetPoint(center, dist, a);
      for (var p = 1; p <= pages; p++) {
        pts.push({ lat: o.lat, lng: o.lng, radius: ringRadius, page: p });
      }
    });
  }

  function escapeHtml(s) {
    return String(s == null ? "" : s)
      .replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;").replace(/'/g, "&#39;");
  }

  function hash(str) {
    var h = 2166136261;
    for (var i = 0; i < str.length; i++) {
      h ^= str.charCodeAt(i);
      h = Math.imul(h, 16777619);
    }
    return (h >>> 0);
  }

  /* 매장 재고 상태: 편의점 앱 API 미연동 → 결정적(항상 같은) 샘플 제보값 */
  var STATUS = ["in", "check", "check", "none", "in", "check"];
  function sampleStatus(id) {
    return STATUS[hash(id) % STATUS.length];
  }
  function sampleObserved(id) {
    var h = hash(id + "t");
    var hh = String(9 + (h % 3)).padStart(2, "0");
    var mm = String((h >>> 3) % 60).padStart(2, "0");
    return "11-17 " + hh + ":" + mm;
  }

  /* ------------------------------------ 매장별 취급·재고 카드 상품 (샘플) */
  var PRODUCTS = (D.cardProducts || []);
  var PRODUCT_STATE_LABEL = {
    in: "입고",
    low: "소량",
    check: "확인 필요",
    soldout: "품절",
    none: "미입고"
  };
  function productById(id) {
    for (var i = 0; i < PRODUCTS.length; i++) if (PRODUCTS[i].id === id) return PRODUCTS[i];
    return null;
  }
  /* 같은 매장은 항상 같은 상품 구성이 나오도록 id 해시로만 고른다. */
  function storeProducts(id, status) {
    if (!PRODUCTS.length) return [];
    var pool = PRODUCTS.slice().sort(function (a, b) {
      return (hash(id + "#" + a.id) % 997) - (hash(id + "#" + b.id) % 997);
    });
    /* 30th CELEBRATION은 10곳 중 7곳에 우선 포함 */
    if (hash(id + "#30th") % 10 < 7) {
      pool = pool.filter(function (p) { return p.id !== "celebration30"; });
      var thirty = productById("celebration30");
      if (thirty) pool.unshift(thirty);
    }
    var n = status === "in" ? 2 + (hash(id + "#n") % 2) : 1 + (hash(id + "#n") % 2);
    var out = [];
    for (var i = 0; i < pool.length && out.length < n; i++) {
      var p = pool[i];
      var h = hash(id + "|" + p.id);
      var stt;
      if (status === "in") stt = h % 4 === 0 ? "low" : "in";
      else if (status === "check") stt = "check";
      else stt = h % 3 === 0 ? "none" : "soldout";
      out.push({
        id: p.id,
        name: p.name,
        short: p.short,
        unit: p.unit,
        state: stt,
        stateLabel: PRODUCT_STATE_LABEL[stt]
      });
    }
    return out;
  }

  /* ------------------------------------------------------- 브랜드 분류 */
  /* 편의점 4사만 분류한다. 그 밖의 업종·브랜드는 null로 돌려 화면에 올리지 않는다.
     카카오 장소 검색 결과의 상호(place_name)·업종(category_name)을 함께 본다. */
  var NAME_RULES = [
    ["gs25", /gs\s*25|지에스\s*25/],
    ["seven", /세븐일레븐|7\s*-?\s*eleven|seven\s*eleven/],
    ["emart24", /emart\s*24|이마트\s*24|emart24/]
  ];
  function classify(tags) {
    tags = tags || {};
    var n = [tags.name, tags["name:ko"], tags.brand, tags["brand:ko"], tags.operator, tags.category]
      .filter(Boolean).join(" ").toLowerCase();
    /* CU는 짧아서 부분 일치하면 오탐이 나므로 토큰 단위로 확인 */
    var tokens = n.split(/[^a-z0-9가-힣]+/);
    if (tokens.indexOf("cu") !== -1) return "cu";
    for (var i = 0; i < NAME_RULES.length; i++) {
      if (NAME_RULES[i][1].test(n)) return NAME_RULES[i][0];
    }
    return null;
  }

  function displayName(name, brand) {
    var meta = D.brandMeta[brand] || { label: brand };
    var nm = (name || "").trim();
    if (!nm) return meta.label + " (명칭 미등록)";
    var norm = nm.replace(/\s+/g, "").toLowerCase();
    var base = meta.label.replace(/\s+/g, "").toLowerCase();
    if (norm === base) return meta.label;
    return nm;
  }

  /* --------------------------------------------- 장소 → 매장 객체 */
  function toStore(o) {
    var id = o.type + "-" + o.id;
    return {
      id: id,
      name: displayName(o.name, o.brand),
      brand: o.brand,
      brandLabel: (D.brandMeta[o.brand] || {}).label || o.brand,
      shop: o.shop,
      lat: o.lat,
      lng: o.lng,
      street: o.street || "",
      distance: 0,
      status: sampleStatus(id),
      observed: sampleObserved(id),
      unit: "낱팩",
      note: "",
      products: [],
      phone: o.phone || "",
      placeUrl: o.placeUrl || "",
      source: o.source
    };
  }

  function prepare(list, center, source) {
    var out = [];
    for (var i = 0; i < list.length; i++) {
      var s = toStore(list[i]);
      s.source = source;
      s.distance = meters(center, s);
      s.products = storeProducts(s.id, s.status);
      out.push(s);
    }
    return out;
  }

  /* ------------------------------------------------------ 카카오 SDK 로드 */
  /* index.html이 SDK 스크립트를 미리 넣어 두지만(autoload=false), 미리보기·
     스크립트 지연에 대비해 없으면 직접 불러온 뒤 kakao.maps.load를 부른다. */
  function ensureKakao(cb) {
    var done = false;
    var timer = setTimeout(function () {
      if (done) return;
      done = true;
      cb(false);
    }, SDK_TIMEOUT);
    function finish(ok) {
      if (done) return;
      done = true;
      clearTimeout(timer);
      cb(ok);
    }
    function boot() {
      if (!window.kakao || !window.kakao.maps) { finish(false); return; }
      try {
        window.kakao.maps.load(function () { finish(!!window.kakao.maps.Map); });
      } catch (e) {
        finish(false);
      }
    }
    if (window.kakao && window.kakao.maps) { boot(); return; }
    var s = document.createElement("script");
    s.async = true;
    s.src = KAKAO_SDK;
    s.onload = boot;
    s.onerror = function () { finish(false); };
    document.head.appendChild(s);
  }

  /* ---------------------------------------------------------- 지도 생성 */
  /* 카카오 지도는 level 1(가까이)~14(멀리)를 쓴다. 기존 Leaflet 줌(9~19)과
     같은 느낌이 나도록 level = 20 - zoom 으로 맞춘다(줌 15 → level 5). */
  function levelForZoom(z) {
    return Math.max(1, Math.min(14, 20 - (z || 15)));
  }

  function latlng(lat, lng) { return new window.kakao.maps.LatLng(lat, lng); }

  function buildMap() {
    if (st.map) return;
    var K = window.kakao.maps;
    var r = region(st.regionId);
    st.map = new K.Map(el.container, {
      center: latlng(r.lat, r.lng),
      level: levelForZoom(r.zoom || 15),
      draggable: true,
      scrollwheel: true,
      disableDoubleClickZoom: false
    });
    st.ready = true;

    try {
      st.map.addControl(new K.ZoomControl(), K.ControlPosition.RIGHT);
    } catch (e) {}

    /* 타일이 그려지면 로딩 오버레이의 1단계를 내린다(이벤트가 없으면 2.5초 뒤) */
    function tilesReady() {
      if (!st.loading.tiles) return;
      st.loading.tiles = false;
      emit("pokemoa:loading", loadingState());
    }
    try {
      K.event.addListener(st.map, "tilesloaded", tilesReady);
    } catch (e) {}
    setTimeout(tilesReady, 2500);

    st.ring = new K.Circle({
      center: latlng(r.lat, r.lng),
      radius: st.radius,
      strokeWeight: 1.5,
      strokeColor: "#2f6df6",
      strokeOpacity: 0.55,
      strokeStyle: "dashed",
      fillColor: "#2f6df6",
      fillOpacity: 0.05
    });
    st.ring.setMap(st.map);

    applyZoomMode();
    try {
      K.event.addListener(st.map, "zoom_changed", function () {
        if (applyZoomMode()) renderMarkers();
      });
    } catch (e) {}
  }

  /* ------------------------------------------------------------- 마커 */
  /* 줌 단계에 따라 마커 모양을 바꾼다.
     · 가까이(level < 7): 브랜드 색 말풍선(알약) + 보유 상품
     · 5km 보기(level 7~9): 작은 브랜드 칩·점 — 매장이 많아도 고르게 퍼진다
     · 20km 보기(level >= 10): 구역별 `N곳` 묶음 */
  var CHIP_LEVEL = 7;
  var CLUSTER_LEVEL = 10;
  var CHIP_CELL = 30;          /* 5km 보기에서 칩이 겹치는지 판단하는 칸 크기(px) */
  function applyZoomMode() {
    var lv = st.map ? st.map.getLevel() : 0;
    var compact = lv >= CHIP_LEVEL;
    var cluster = lv >= CLUSTER_LEVEL;
    var changed = compact !== st.compact || cluster !== st.cluster;
    st.compact = compact;
    st.cluster = cluster;
    return changed;
  }

  function stockProductCount(s) {
    var n = 0;
    (s.products || []).forEach(function (p) {
      if (p.state === "in" || p.state === "low") n += 1;
    });
    return n;
  }

  function pillHtml(s) {
    var b = D.brandMeta[s.brand] || { short: "?", color: "#1b2a4a" };
    var html;
    if (st.compact) {
      html = s.status === "in"
        ? '<span class="pm-pill is-chip status-in" style="--brand:' + b.color + '">' + b.short + "</span>"
        : '<span class="pm-pill is-dot status-' + s.status + '"></span>';
    } else if (s.status === "in" && s.relay) {
      var q = s.relayQty || 0;
      html = '<span class="pm-pill status-in is-relay" style="--brand:' + b.color + '">' +
        "<b>" + b.short + "</b><span>" + (q ? q + "개" : "재고") + "</span></span>";
    } else if (s.status === "in") {
      var n = stockProductCount(s);
      html = '<span class="pm-pill status-in" style="--brand:' + b.color + '">' +
        "<b>" + b.short + "</b><span>" + (n ? "입고 " + n + "종" : "재고 있음") + "</span></span>";
    } else {
      html = '<span class="pm-pill status-' + s.status + '">' +
        '<i class="pm-dot" style="background:' + b.color + '"></i>' +
        "<span>" + (s.status === "check" ? "확인" : (s.relay ? "실시간 0개" : "없음")) + "</span></span>";
    }
    return html;
  }

  function pillNode(s, label) {
    var node = document.createElement("div");
    node.className = "pm-marker status-" + s.status + (st.compact ? " is-compact" : "");
    node.innerHTML = pillHtml(s);
    node.setAttribute("role", "button");
    node.setAttribute("tabindex", "0");
    node.setAttribute("aria-label", label);
    node.title = label;
    node.addEventListener("click", function (e) {
      e.stopPropagation();
      select(s.id, true);
    });
    node.addEventListener("keydown", function (e) {
      if (e.key === "Enter" || e.key === " ") {
        e.preventDefault();
        select(s.id, true);
      }
    });
    return node;
  }

  function addOverlay(node, lat, lng, opts) {
    var o = opts || {};
    var ov = new window.kakao.maps.CustomOverlay({
      position: latlng(lat, lng),
      content: node,
      xAnchor: o.xAnchor != null ? o.xAnchor : 0.5,
      yAnchor: o.yAnchor != null ? o.yAnchor : 1,
      zIndex: o.zIndex || 100,
      clickable: !!o.clickable
    });
    ov.setMap(st.map);
    st.layer.push(ov);
    return ov;
  }

  function clearOverlays() {
    st.layer.forEach(function (ov) { try { ov.setMap(null); } catch (e) {} });
    st.layer = [];
    st.markers = {};
  }

  function brandOrder(b) {
    return ({ gs25: 0, cu: 1, seven: 2, emart24: 3 })[b] || 9;
  }

  /* 같은 화면 칸(px)에 들어온 매장을 한 묶음으로 모은다 — proj가 없으면 좌표 스케일로 대신한다 */
  function groupStores(list, cell) {
    var groups = {};
    var proj = null;
    try { proj = st.map.getProjection(); } catch (e) {}
    list.forEach(function (s) {
      var pt;
      try { pt = proj.containerPointFromCoords(latlng(s.lat, s.lng)); } catch (e) { pt = null; }
      if (!pt) { pt = { x: s.lng * 1000, y: s.lat * 1000 }; }
      var key = Math.floor(pt.x / cell) + ":" + Math.floor(pt.y / cell);
      var g = groups[key] || (groups[key] = { lat: 0, lng: 0, n: 0, in: 0, names: [], items: [] });
      g.lat += s.lat;
      g.lng += s.lng;
      g.n += 1;
      if (s.status === "in") g.in += 1;
      if (g.names.length < 3) g.names.push(s.name);
      g.items.push(s);
    });
    return groups;
  }

  /* 구역 묶음 배지 — 누르면 그 자리로 확대한다(step 단계).
     mini=true는 5km 보기의 작은 원(숫자만) */
  function drawClusterBadge(g, step, mini) {
    var ll = { lat: g.lat / g.n, lng: g.lng / g.n };
    var node = document.createElement("div");
    node.className = "pm-marker-cluster";
    node.innerHTML = mini
      ? '<span class="pm-cluster is-mini' + (g.in ? " has-stock" : "") + '">' + g.n + "</span>"
      : '<span class="pm-cluster' + (g.in ? " has-stock" : "") + '">' +
        g.n + "곳" + (g.in ? "<small>재고 " + g.in + "</small>" : "") + "</span>";
    node.title = g.names.join(", ") + (g.n > 3 ? " 외" : "");
    node.setAttribute("role", "button");
    node.setAttribute("tabindex", "0");
    node.setAttribute("aria-label", g.n + "곳 (" + node.title + ")");
    function zoomIn() {
      st.map.setLevel(Math.max(1, st.map.getLevel() - (step || 3)));
      st.map.setCenter(latlng(ll.lat, ll.lng));
    }
    node.addEventListener("click", zoomIn);
    node.addEventListener("keydown", function (e) {
      if (e.key === "Enter" || e.key === " ") { e.preventDefault(); zoomIn(); }
    });
    addOverlay(node, ll.lat, ll.lng, { xAnchor: 0.5, yAnchor: 0.5, zIndex: 60, clickable: true });
  }

  /* 넓게 보는 저줌(20km)에서는 같은 구역의 매장을 `N곳` 한 덩이로 표시한다 */
  function renderClusters(list) {
    var level = st.map.getLevel();
    /* 줌이 낮을수록 넓은 칸으로 묶되, 20km(level 10)에서는 칸을 줄여
       반경 전역이 지역별 여러 묶음으로 나뉘어 보이게 한다 */
    var cell = level >= 11 ? 85 : level >= 10 ? 58 : 40;
    var groups = groupStores(list, cell);
    Object.keys(groups).forEach(function (k) { drawClusterBadge(groups[k], 3); });
  }

  /* 5km 보기(브랜드 칩 모드): 칩이 겹치는 자리는 숫자만 담은 작은 원,
     외딴 매장은 브랜드 칩·점 그대로 */
  function renderChipGroups(list) {
    var groups = groupStores(list, CHIP_CELL);
    Object.keys(groups).forEach(function (k) {
      var g = groups[k];
      if (g.n === 1) drawPill(g.items[0]);
      else drawClusterBadge(g, 2, true);
    });
  }

  /* 매장 하나 = 말풍선(알약) 또는 저줌에서는 브랜드 칩·점 */
  function drawPill(s) {
    var label = s.name + " · " + statusLabel(s.status) +
      (s.products && s.products.length
        ? " · " + s.products.map(function (p) { return p.short + " " + p.stateLabel; }).join(", ")
        : "");
    var node = pillNode(s, label);
    var ov = addOverlay(node, s.lat, s.lng, {
      xAnchor: 0.5,
      yAnchor: 1,
      zIndex: s.status === "in" ? 300 : 100,
      clickable: true
    });
    st.markers[s.id] = { ov: ov, node: node };
    if (st.selectedId === s.id) {
      node.classList.add("is-selected");
      try { ov.setZIndex(900); } catch (e) {}
    }
  }

  function renderMarkers() {
    applyZoomMode();
    if (st.ready) clearOverlays();
    var cap = st.radius >= 20000 ? MAX_MARKERS_20 : st.radius >= 5000 ? MAX_MARKERS_5 : MAX_MARKERS;
    var list = st.all.filter(match).slice().sort(function (a, b) {
      return a.distance - b.distance;
    });
    /* 가까운 순으로 상한 적용 (20km는 최대 100곳) */
    if (list.length > cap) list = list.slice(0, cap);
    /* 마커는 브랜드가 고르게 보이도록 브랜드 → 거리 순으로 그린다 */
    list.sort(function (a, b) {
      var d = brandOrder(a.brand) - brandOrder(b.brand);
      return d !== 0 ? d : a.distance - b.distance;
    });
    st.visible = list.map(function (s) { return s; });
    st.visible.sort(function (a, b) { return a.distance - b.distance; });

    /* 카카오맵을 그릴 수 없는 주소: 마커 대신 목록·집계만 그대로 산출한다 */
    if (!st.ready) {
      emit("pokemoa:visible", { stores: st.visible });
      return;
    }

    if (st.cluster) {
      renderClusters(st.visible);
      if (st.selectedId) closeCard();
    } else if (st.compact) {
      renderChipGroups(st.visible);
      if (st.selectedId && !st.markers[st.selectedId]) closeCard();
    } else {
      st.visible.forEach(drawPill);
      if (st.selectedId && !st.markers[st.selectedId]) closeCard();
    }
    emit("pokemoa:visible", { stores: st.visible });
  }

  function match(s) {
    if (st.brand !== "all" && s.brand !== st.brand) return false;
    if (s.distance > st.radius) return false;
    if (st.stockOnly && s.status !== "in") return false;
    if (st.product !== "all") {
      /* 그 상품을 취급했거나 입고·확인 중인 매장만 (한 번도 입고 안 된 '미입고'는 제외) */
      var hit = (s.products || []).some(function (p) {
        return p.id === st.product && p.state !== "none";
      });
      if (!hit) return false;
    }
    return true;
  }

  /* --------------------------------------------------------- 정보 카드 */
  function select(id, fromMap) {
    var s = null;
    for (var i = 0; i < st.visible.length; i++) if (st.visible[i].id === id) s = st.visible[i];
    if (!s) return;
    st.selectedId = id;
    Object.keys(st.markers).forEach(function (k) {
      var m = st.markers[k];
      if (!m) return;
      m.node.classList.toggle("is-selected", k === id);
      try { m.ov.setZIndex(k === id ? 900 : (m.node.classList.contains("status-in") ? 300 : 100)); } catch (e) {}
    });
    renderCard(s);
    el.container.classList.add("is-card-open");
    emit("pokemoa:store-selected", { id: id });
    if (fromMap && window.innerWidth < 980) {
      /* 모바일: 카드가 지도 하단에 고정되므로 지도만 보이도록 스크롤 유지 */
      el.container.scrollIntoView({ behavior: "smooth", block: "center" });
    }
  }

  function closeCard() {
    st.selectedId = null;
    if (el.card) el.card.hidden = true;
    if (el.container) el.container.classList.remove("is-card-open");
    emit("pokemoa:store-cleared");
  }

  function statusLabel(s) {
    return s === "in" ? "재고 있음" : s === "check" ? "매장 확인 필요" : "재고 없음";
  }

  /* 취급·재고 카드 상품명 태그 (목록·팝업 공용) */
  function productTagsHtml(s, cls, withHead) {
    var list = s.products || [];
    if (!list.length) return "";
    var soldout = list.some(function (p) { return p.state === "soldout"; });
    var head = "";
    if (s.status === "none") {
      /* 품절 이력이 있으면 머리표로, 전부 미입고면 태그의 '미입고'만으로 충분하다 */
      head = soldout ? '<span class="p-head">최근 입고 품절</span>' : "";
    } else if (withHead) {
      head = '<span class="p-head p-head-label">보유 카드</span>';
    }
    var tags = list.map(function (p) {
      return '<span class="p-tag is-' + p.state + '" title="' + p.name + " · " + p.stateLabel + '">' +
        p.short + ' <i>· ' + p.stateLabel + "</i></span>";
    }).join("");
    return '<div class="store-products ' + (cls || "") + '">' + head + tags + "</div>";
  }

  function renderCard(s) {
    if (!el.card) return;
    var meta = D.brandMeta[s.brand] || { label: s.brand, color: "#1b2a4a", short: "?" };
    var dist = s.distance < 1000 ? Math.round(s.distance) + "m" : (s.distance / 1000).toFixed(1) + "km";
    var navLink = "https://map.naver.com/p/search/" + encodeURIComponent(s.name);
    /* 매장명이 브랜드명뿐이면 부제에서 브랜드를 한 번 더 쓰지 않는다 */
    var subBits = [];
    if (s.name.indexOf(meta.label) !== 0) subBits.push(meta.label);
    if (s.street) subBits.push(s.street);
    subBits.push(dist);
    var subLine = subBits.join(" · ");
    el.card.hidden = false;
    el.card.innerHTML =
      '<div class="pm-card-head">' +
      '<span class="pm-card-brand" style="background:' + meta.color + '">' + meta.short + "</span>" +
      '<div class="pm-card-title"><strong>' + s.name + "</strong>" +
      "<span>" + subLine + "</span></div>" +
      '<button type="button" class="pm-card-close" aria-label="닫기">×</button>' +
      "</div>" +
      '<div class="pm-card-meta">' +
      '<span class="status-badge ' + s.status + '">' + statusLabel(s.status) + "</span>" +
      (s.relay
        ? '<span class="chip chip-relay">실시간 재고</span>'
        : '<span class="chip chip-sample">샘플 재고</span>') +
      '<span class="chip">' + s.observed + "</span>" +
      (s.phone ? '<span class="chip">' + escapeHtml(s.phone) + "</span>" : "") +
      "</div>" +
      productTagsHtml(s, "pm-card-products", true) +
      (s.relay
        ? '<p class="pm-card-note">집 태블릿 중계 서버가 편의점 앱에서 <b>조회한 실제 재고</b>입니다(조회 ' + escapeHtml(s.observed) + '). 수량은 조회 시점 기준이므로 방문 전 매장 전화로 한 번 더 확인하세요.</p>'
        : '<p class="pm-card-note">매장 위치·상호는 카카오맵 실제 장소 데이터입니다. 재고 상태와 <b>취급 카드 상품명</b>은 편의점 앱 API 미연동으로 <b>제보·샘플 기반</b> 표시이니, 방문 전 공식 앱이나 매장 전화로 확인하세요.</p>') +
      '<a class="btn btn-sm btn-dark pm-card-link" target="_blank" rel="noopener" href="' + navLink + '">네이버 지도에서 보기</a>';
    el.card.querySelector(".pm-card-close").addEventListener("click", function (e) {
      e.stopPropagation();
      closeCard();
    });
  }

  /* ------------------------------------------------------- 상태 표기 */
  function loadingState() {
    var msg, phase, progress;
    if (st.loading.tiles) {
      phase = "tiles";
      msg = "카카오맵 지도를 불러오는 중...";
      progress = 34;
    } else if (st.loading.data) {
      phase = "data";
      msg = "주변 편의점 4사를 찾는 중... (카카오 장소 검색)";
      progress = 72;
    } else {
      phase = "done";
      msg = "불러오기 완료";
      progress = 100;
    }
    return {
      active: st.loading.tiles || st.loading.data,
      phase: phase,
      message: msg,
      progress: progress
    };
  }

  function pushLoading() {
    emit("pokemoa:loading", loadingState());
  }

  function badge() {
    if (st.geoBusy) {
      return { kind: "busy", text: "내 위치 확인 중 · 브라우저 위치 권한을 허용해 주세요", action: false };
    }
    if (st.sdkError) {
      return {
        kind: "snapshot",
        text: "카카오맵을 이 주소에서 열 수 없어 내장 실제 좌표로 표시합니다 (등록 도메인 https://moa-kr.github.io 에서 지도가 열립니다)",
        action: true
      };
    }
    if (st.loading.data && !(st.relay && st.relay.count)) {
      return { kind: "busy", text: "카카오 장소 검색으로 주변 편의점 4사를 찾는 중입니다 (보통 1초 이내)", action: false };
    }
    /* 집 태블릿 중계로 실제 재고를 받았으면 그 사실을 먼저 알린다 */
    if (st.relay && st.relay.count) {
      var names = [];
      RELAY_ORDER.forEach(function (k) {
        var src = (st.relay.sources || {})[k];
        if (src && src.ok && src.count) names.push(RELAY_LABEL[k]);
      });
      return {
        kind: "relay",
        text: "실시간 중계 · " + (names.length ? names.join("·") + " " : "") + "실제 재고 " + st.relay.count +
          "곳 · 조회 " + relayTimeLabel(st.relayAt),
        action: false
      };
    }
    if (st.source === "live") {
      var cap = st.radius >= 20000 ? MAX_MARKERS_20 : st.radius >= 5000 ? MAX_MARKERS_5 : MAX_MARKERS;
      var txt = st.all.length > cap
        ? "실시간 조회 · 카카오맵 주변 매장 " + st.all.length + "곳 중 가까운 " + cap + "곳 표시"
        : "실시간 조회 · 카카오맵 주변 편의점 4사 " + st.all.length + "곳";
      return { kind: "live", text: txt, action: false };
    }
    var snapKm = Math.round(((D.osmSnapshot || {}).radius || 3000) / 1000);
    var wideNote = st.radius >= 20000 ? " · 넓은 반경은 실시간 조회에서만 표시" : "";
    return {
      kind: "snapshot",
      text: (st.pendingLive
        ? "카카오 장소 검색이 늦어 내장 실제 좌표(반경 " + snapKm + "km)로 먼저 표시 (조금 더 기다리는 중 · " + st.snapshotLabel + ")"
        : "실시간 조회 실패/제한 → 내장 실제 좌표 스냅샷(반경 " + snapKm + "km) 사용 (" + st.snapshotLabel + ")" + wideNote),
      action: true
    };
  }

  /* 브랜드별 현황 (반경·재고 필터를 반영한 집계) */
  function blankCount() { return { total: 0, in: 0, check: 0, none: 0 }; }
  function brandCounts() {
    var out = { all: blankCount(), gs25: blankCount(), cu: blankCount(), seven: blankCount(), emart24: blankCount() };
    (st.all || []).forEach(function (s) {
      if (s.distance > st.radius) return;
      if (st.stockOnly && s.status !== "in") return;
      var row = out[s.brand];
      if (!row) return;
      out.all.total += 1;
      out.all[s.status] += 1;
      row.total += 1;
      row[s.status] += 1;
    });
    return out;
  }

  function pushData() {
    st.snapshotLabel = (D.osmSnapshot && D.osmSnapshot.fetchedAt) || "";
    emit("pokemoa:data", {
      stores: st.visible,
      loading: st.loading.data || st.loading.tiles,
      source: st.source,
      badge: badge(),
      regionId: st.regionId,
      origin: st.origin,
      center: st.center,
      radius: st.radius,
      total: st.all.length,
      product: st.product,
      stockOnly: st.stockOnly,
      brand: st.brand,
      brandCounts: brandCounts(),
      allow20: allow20(),
      markerCap: st.radius >= 20000 ? MAX_MARKERS_20 : MAX_MARKERS,
      snapshotAt: (D.osmSnapshot || {}).fetchedAt || "",
      error: st.lastError
    });
  }

  /* --------------------------------------------------- 데이터 조회 */
  function snapshotList() {
    var snap = (D.osmSnapshot && D.osmSnapshot.items) || [];
    if (st.origin === "region") {
      return snap.filter(function (s) { return s.regionId === st.regionId; });
    }
    /* 내 위치·장소 검색 기준일 때는 25km 안에 있는 스냅샷만 후보로 둔다 */
    var c = st.center;
    return snap.filter(function (s) { return meters(c, s) <= 25000; });
  }

  /* ------------------------------------------- 카카오 장소 검색 (Places) */
  function placesService() {
    var K = window.kakao.maps.services;
    return new K.Places();
  }

  /* 편의점 카테고리(CS2) 한 페이지 — 15건, 페이지를 넘기면 최대 45건 */
  function categoryPage(center, radius, page) {
    return new Promise(function (resolve) {
      var P = window.kakao.maps.services;
      placesService().categorySearch("CS2", function (data, status) {
        resolve({ ok: status === P.Status.OK, data: data || [] });
      }, {
        location: latlng(center.lat, center.lng),
        radius: Math.min(20000, Math.max(100, Math.round(radius))),
        sort: P.SortBy.DISTANCE,
        page: page || 1,
        size: 15
      });
    });
  }

  /* 브랜드별 키워드 검색 — 카테고리 조회 45건에 없는 브랜드를 보충한다 */
  function keywordPage(query, center, radius, page) {
    return new Promise(function (resolve) {
      var P = window.kakao.maps.services;
      placesService().keywordSearch(query, function (data, status) {
        resolve({ ok: status === P.Status.OK, data: data || [] });
      }, {
        location: latlng(center.lat, center.lng),
        radius: Math.min(20000, Math.max(100, Math.round(radius))),
        sort: P.SortBy.DISTANCE,
        page: page || 1,
        size: 15
      });
    });
  }

  function placeToRow(p) {
    var brand = classify({ name: p.place_name, category: p.category_name });
    if (!brand) return null;
    var lat = Number(p.y);
    var lng = Number(p.x);
    if (!isFinite(lat) || !isFinite(lng)) return null;
    return {
      id: p.id || (p.place_name + ":" + lat + ":" + lng),
      type: "kakao",
      name: p.place_name || "",
      brand: brand,
      shop: "convenience",
      lat: lat,
      lng: lng,
      street: p.road_address_name || p.address_name || "",
      phone: p.phone || "",
      placeUrl: p.place_url || ""
    };
  }

  function rowsFrom(pages) {
    var out = [];
    var seen = {};
    pages.forEach(function (pg) {
      (pg.data || []).forEach(function (p) {
        var row = placeToRow(p);
        if (!row || seen[row.id]) return;
        seen[row.id] = 1;
        out.push(row);
      });
    });
    return out;
  }

  /* 반경별 조회 계획 — {lat,lng,radius,page} 목록
     · ~3km: 중심 1곳에서 3페이지(최대 45건, 1초 안팎)
     · 5km: 중심(반경 3km·2p) + 동·서·남·북 2.8km 지점(반경 2.6km·2p)
     · 20km: 중심(반경 5km·2p) + 반경 5km 고리(8방위 · 4km · 1p) + 반경 13km 고리(8방위 · 7km · 1p)
       → 중심만 조회하면 45건 상한에 가까운 매장이 차서 외곽이 통째로 빠지므로,
         여러 지점에서 나눠 받아 합친 뒤 반경으로 다시 거른다. */
  function searchPlan(center, radius) {
    var pts = [];
    var p;
    if (radius >= 20000) {
      for (p = 1; p <= 2; p++) pts.push({ lat: center.lat, lng: center.lng, radius: 5000, page: p });
      pushRing(pts, center, 5000, 4000, 1, DIRS8);
      pushRing(pts, center, 13000, 7000, 1, DIRS8);
      return pts;
    }
    if (radius > 3000) {
      for (p = 1; p <= 2; p++) pts.push({ lat: center.lat, lng: center.lng, radius: 3000, page: p });
      pushRing(pts, center, 2800, 2600, 2, DIRS4);
      return pts;
    }
    for (p = 1; p <= 3; p++) pts.push({ lat: center.lat, lng: center.lng, radius: radius, page: p });
    return pts;
  }

  /* 격자 조회 → id 중복 제거 → 반경 필터 → 빠진 브랜드는 브랜드별 키워드 1페이지로 보충 */
  function searchNearby(center, radius) {
    var reqs = searchPlan(center, radius).map(function (pt) {
      return categoryPage(pt, pt.radius, pt.page);
    });
    return Promise.all(reqs).then(function (pages) {
      var anyOk = pages.some(function (p) { return p.ok; });
      if (!anyOk) throw new Error("place-search-failed");
      var rows = rowsFrom(pages).filter(function (r) { return meters(center, r) <= radius + 1; });
      var missing = BRAND_ORDER_LIST.filter(function (b) {
        return !rows.some(function (r) { return r.brand === b; });
      });
      if (!missing.length) return rows;
      var extra = missing.map(function (b) { return keywordPage(BRAND_QUERY[b], center, radius, 1); });
      return Promise.all(extra).then(function (pages2) {
        var more = rowsFrom(pages2).filter(function (r) {
          return missing.indexOf(r.brand) >= 0 && meters(center, r) <= radius + 1;
        });
        return rows.concat(more);
      });
    });
  }

  function load() {
    var seq = ++st.seq;
    st.loading.data = true;
    st.lastError = null;
    st.pendingLive = false;
    pushLoading();
    pushData();

    if (!st.ready) {
      /* 지도가 없으면(SDK 미등록 도메인·차단) 스냅샷으로 조용히 표시한다 */
      applySnapshot(seq, st.sdkError ? "kakao-sdk-unavailable" : "map-not-ready");
      return;
    }

    var center = st.center;
    var radius = st.radius;
    st.fetchedRadius = radius;
    st.fetchedBand = radiusBand(radius);

    var softTimer = setTimeout(function () {
      if (seq !== st.seq) return;
      if (st.source === "live") return;
      st.pendingLive = true;
      applySnapshot(seq, "timeout");
    }, SEARCH_TIMEOUT);

    searchNearby(center, radius).then(function (rows) {
      clearTimeout(softTimer);
      if (seq !== st.seq) return;
      st.all = prepare(rows, center, "live");
      st.source = "live";
      st.lastError = null;
      st.pendingLive = false;
      st.loading.data = false;
      finishLoad(seq, true);
    }).catch(function (err) {
      clearTimeout(softTimer);
      if (seq !== st.seq) return;
      if (st.source === "live") return;
      st.pendingLive = false;
      applySnapshot(seq, String((err && err.message) || err));
    });
  }

  function applySnapshot(seq, reason) {
    var center = st.center;
    var rows = snapshotList();
    st.all = prepare(rows, center, "snapshot");
    st.source = "snapshot";
    st.lastError = reason;
    st.loading.data = false;
    st.loading.tiles = false;
    finishLoad(seq, false);
  }

  function finishLoad(seq, liveNow) {
    if (seq !== st.seq) return;
    renderMarkers();
    pushLoading();
    pushData();
    emit("pokemoa:loaded", {
      source: st.source,
      total: st.all.length,
      allow20: allow20(),
      markerCap: st.radius >= 20000 ? MAX_MARKERS_20 : st.radius >= 5000 ? MAX_MARKERS_5 : MAX_MARKERS,
      error: st.lastError,
      late: !!liveNow && st.badgeWasSnapshot
    });
    st.badgeWasSnapshot = st.source === "snapshot";
  }

  /* ------------------------------------- 집 태블릿 중계 실재고(relay) */
  /* 중계 서버는 편의점 앱 재고를 대신 조회해 { stores: [{ brand, name, address,
     lat, lng, distanceM, status, items:[{name,qty,code}], updatedAt }] } 로 준다.
     이 값은 실제 재고이므로 같은 자리의 지도 매장이 있으면 그 매장 카드에 얹고,
     없으면 중계 매장을 새로 그린다. 해제하면 원래 샘플 상태로 되돌린다. */
  var RELAY_ORDER = ["emart24", "cu", "seven"];
  var RELAY_LABEL = { emart24: "이마트24", cu: "CU", seven: "세븐일레븐" };

  function relayTimeLabel(iso) {
    var d = iso ? new Date(iso) : new Date();
    if (isNaN(d.getTime())) d = new Date();
    return String(d.getHours()).padStart(2, "0") + ":" + String(d.getMinutes()).padStart(2, "0");
  }

  function relayProducts(items) {
    return (items || []).map(function (it) {
      var qty = Number(it.qty);
      if (!isFinite(qty)) qty = 0;
      var state = qty > 0 ? "in" : "soldout";
      return {
        id: String(it.code || it.name || ""),
        name: String(it.name || it.code || ""),
        short: String(it.name || it.code || ""),
        unit: "개",
        qty: qty,
        state: state,
        stateLabel: qty > 0 ? qty + "개" : "0개"
      };
    });
  }

  function toRelayStore(s) {
    var brand = RELAY_ORDER.indexOf(s.brand) >= 0 ? s.brand : null;
    if (!brand) return null;
    var lat = Number(s.lat);
    var lng = Number(s.lng);
    if (!isFinite(lat) || !isFinite(lng)) return null;
    var meta = D.brandMeta[brand] || { label: RELAY_LABEL[brand] || brand };
    var products = relayProducts(s.items);
    var total = 0;
    products.forEach(function (p) { total += p.qty; });
    return {
      id: "relay-" + (s.id || brand + ":" + (s.name || "") + ":" + lat + ":" + lng),
      brand: brand,
      brandLabel: meta.label || brand,
      shop: "convenience",
      name: (s.name || "").trim() || (RELAY_LABEL[brand] || brand),
      lat: lat,
      lng: lng,
      street: s.address || "",
      distance: 0,
      status: s.status === "in_stock" ? "in" : "none",
      observed: relayTimeLabel(s.updatedAt),
      unit: "개",
      note: "",
      products: products,
      relay: true,
      relayQty: total,
      source: "relay"
    };
  }

  function applyRelay(payload) {
    if (!st.center) return 0;
    var list = ((payload && payload.stores) || []).map(toRelayStore).filter(Boolean);
    /* 이전 중계 결과는 원래 상태로 되돌리고 새로 얹는다 */
    restoreRelayBase();
    var base = st.all;
    list.forEach(function (r) {
      r.distance = meters(st.center, r);
      var twin = null;
      for (var i = 0; i < base.length; i++) {
        var b = base[i];
        if (b.brand === r.brand && meters(b, r) < 80) { twin = b; break; }
      }
      if (twin && !twin.relay) {
        /* 지도로 그려둔 같은 매장 — 원래 값을 저장해 두고 중계 값으로 잠시 바꿔 쓴다 */
        twin.relayBase = {
          name: twin.name, status: twin.status, observed: twin.observed,
          products: twin.products, street: twin.street, source: twin.source, relayQty: null
        };
        twin.name = r.name || twin.name;
        twin.status = r.status;
        twin.observed = r.observed;
        twin.products = r.products;
        twin.relay = true;
        twin.relayQty = r.relayQty;
        twin.source = "relay";
        if (r.street) twin.street = r.street;
      } else if (!twin) {
        r.distance = meters(st.center, r);
        base.push(r);
      }
    });
    st.relayAt = (payload && payload.generatedAt) || new Date().toISOString();
    st.relay = {
      ok: !!(payload && payload.ok),
      sources: (payload && payload.sources) || {},
      at: Date.now(),
      count: list.length
    };
    renderMarkers();
    pushData();
    return list.length;
  }

  function restoreRelayBase() {
    if (!st.all) return;
    st.all = st.all.filter(function (s) {
      if (s.relay && s.relayBase) {
        s.name = s.relayBase.name;
        s.status = s.relayBase.status;
        s.observed = s.relayBase.observed;
        s.products = s.relayBase.products;
        s.street = s.relayBase.street;
        s.relay = false;
        delete s.relayQty;
        s.source = s.relayBase.source || "live";
        delete s.relayBase;
        return true;
      }
      return !s.relay;   /* 순수 중계 매장은 빼고 지도·스냅샷 매장만 남깁니다 */
    });
  }

  function clearRelay() {
    if (!st.relay) return;
    restoreRelayBase();
    st.relay = null;
    st.relayAt = "";
    if (st.selectedId && !st.all.some(function (s) { return s.id === st.selectedId; })) closeCard();
    renderMarkers();
    pushData();
  }

  /* ---------------------------------------------------------- 공개 API */
  function setView(center, zoom) {
    if (!st.ready) return;
    st.map.setCenter(latlng(center.lat, center.lng));
    st.map.setLevel(levelForZoom(zoom || 15));
    if (st.ring) {
      st.ring.setPosition(latlng(center.lat, center.lng));
      st.ring.setRadius(st.radius);
    }
  }

  function allow20() { return st.allow20 !== false; }

  /* 반경 구간 — 구간마다 장소 검색 계획이 달라 그 구분이 바뀌면 다시 조회한다 */
  function radiusBand(r) {
    return r >= 20000 ? "20" : r > 3000 ? "5" : "3";
  }

  function fitRing() {
    if (!st.ready || !st.ring) return;
    try { st.map.setBounds(st.ring.getBounds()); } catch (e) {}
  }

  function setRadius(radius) {
    if (radius > 5000 && !allow20()) radius = 5000;
    var before = st.radius;
    st.radius = radius;
    if (st.ring) st.ring.setRadius(radius);
    /* 5km·20km는 반경 원 전체가 화면에 들어오도록 지도를 맞춘다 */
    if (radius >= 5000) {
      fitRing();
    } else if (before >= 5000 && st.ready && st.center) {
      /* 넓게 보던 지도에서 1km·3km로 좁힐 때는 기본 확대(줌 15)로 되돌린다 */
      setView(st.center, 15);
    }
    renderMarkers();
    pushData();
    /* 반경 구분(3·5·20km)이 바뀌었거나 조회 범위보다 넓어졌으면(스냅샷 포함)
       그 반경으로 다시 조회한다 — 격자 조회 방식이 달라 20km 결과를 5km에 그대로 쓰면
       실제 5km 매장보다 적게 보인다. */
    if (radius !== before && (radiusBand(radius) !== st.fetchedBand || radius > st.fetchedRadius)) {
      renderMarkers();
      load();
    }
  }

  function setBrand(brand) {
    st.brand = brand;
    renderMarkers();
    pushData();
  }

  function setProduct(id) {
    st.product = id || "all";
    renderMarkers();
    pushData();
  }

  function setStockOnly(on) {
    st.stockOnly = !!on;
    renderMarkers();
    pushData();
  }

  function resetStateForNewCenter() {
    st.fetchedRadius = st.radius;
    st.fetchedBand = radiusBand(st.radius);
    st.source = "snapshot";
    st.all = [];
    st.visible = [];
    closeCard();
  }

  function setRegion(id) {
    var r = region(id);
    st.regionId = r.id;
    st.origin = "region";
    st.allow20 = r.allow20 !== false;
    st.metro = !st.allow20;
    if (!st.allow20 && st.radius > 5000) st.radius = 5000;
    st.center = { lat: r.lat, lng: r.lng };
    resetStateForNewCenter();
    if (st.ready) {
      st.loading.tiles = false;
      setView(st.center, st.radius >= 20000 ? (r.zoom || 12) : (r.zoom || 15));
      if (st.ring) st.ring.setRadius(st.radius);
      /* 20km 반경을 고른 상태에서 지역만 바꾸면 반경 전체가 보이도록 맞춘다 */
      if (st.radius >= 20000) fitRing();
    }
    renderMarkers();
    load();
  }

  /* 동네·역 이름 검색 결과(카카오 장소 검색)로 임의 좌표를 볼 때 */
  function setPoint(point) {
    if (!point || !isFinite(point.lat) || !isFinite(point.lng)) return;
    st.origin = "search";
    st.regionId = "";
    st.center = { lat: Number(point.lat), lng: Number(point.lng) };
    st.metro = metroRegions().some(function (r) {
      return meters(st.center, { lat: r.lat, lng: r.lng }) < METRO_RADIUS_M;
    });
    st.allow20 = !st.metro;
    if (!st.allow20 && st.radius > 5000) st.radius = 5000;
    resetStateForNewCenter();
    if (st.ready) {
      st.loading.tiles = false;
      setView(st.center, st.radius >= 20000 ? 12 : 15);
      if (st.ring) st.ring.setRadius(st.radius);
      if (st.radius >= 20000) fitRing();
    }
    renderMarkers();
    load();
  }

  /* 동네·역 이름 → 좌표 (카카오 장소 검색). 결과는 callback(list)로 돌려준다. */
  function searchPlaces(query, cb) {
    if (!query || !window.kakao || !window.kakao.maps || !window.kakao.maps.services) {
      if (cb) cb([]);
      return;
    }
    var P = window.kakao.maps.services;
    try {
      placesService().keywordSearch(query, function (data, status) {
        if (!cb) return;
        if (status !== P.Status.OK || !data) { cb([]); return; }
        cb(data.slice(0, 6).map(function (p) {
          return {
            name: p.place_name,
            address: p.road_address_name || p.address_name || "",
            category: p.category_name || "",
            lat: Number(p.y),
            lng: Number(p.x)
          };
        }).filter(function (p) { return isFinite(p.lat) && isFinite(p.lng); }));
      }, { size: 6, sort: P.SortBy.ACCURACY });
    } catch (e) {
      if (cb) cb([]);
    }
  }

  function locate() {
    if (!navigator.geolocation) {
      emit("pokemoa:geo-error", { message: "이 브라우저는 위치 정보를 지원하지 않습니다. 지역을 선택해 주세요." });
      return;
    }
    st.geoBusy = true;
    pushData();
    emit("pokemoa:geo-start", {});
    navigator.geolocation.getCurrentPosition(function (pos) {
      st.geoBusy = false;
      st.origin = "geo";
      st.center = { lat: pos.coords.latitude, lng: pos.coords.longitude };
      st.metro = metroRegions().some(function (r) {
        return meters(st.center, { lat: r.lat, lng: r.lng }) < METRO_RADIUS_M;
      });
      st.allow20 = !st.metro;
      if (!st.allow20 && st.radius > 5000) st.radius = 5000;
      st.fetchedRadius = st.radius;
      st.fetchedBand = radiusBand(st.radius);
      st.regionId = "";
      if (st.ready) {
        st.loading.tiles = false;
        setView(st.center, 15);
        if (st.meMarker) { try { st.meMarker.setMap(null); } catch (e) {} }
        var node = document.createElement("div");
        node.className = "pm-me";
        node.innerHTML = '<span class="pm-me-dot"></span><span class="pm-me-label">내 위치</span>';
        st.meMarker = new window.kakao.maps.CustomOverlay({
          position: latlng(st.center.lat, st.center.lng),
          content: node,
          xAnchor: 0.5,
          yAnchor: 0.5,
          zIndex: 950
        });
        st.meMarker.setMap(st.map);
      }
      emit("pokemoa:geo-done", { lat: st.center.lat, lng: st.center.lng });
      load();
    }, function (err) {
      st.geoBusy = false;
      var msg = "위치를 가져오지 못했습니다.";
      if (err && err.code === 1) msg = "브라우저 위치 권한이 차단되어 있습니다. 주소창의 위치 권한을 허용하거나 아래 지역을 선택해 주세요.";
      else if (err && err.code === 2) msg = "현재 위치를 확인할 수 없습니다. 잠시 후 다시 시도하거나 지역을 선택해 주세요.";
      else if (err && err.code === 3) msg = "위치 확인 시간이 초과되었습니다. 다시 시도하거나 지역을 선택해 주세요.";
      pushData();
      emit("pokemoa:geo-error", { message: msg });
    }, { enableHighAccuracy: true, timeout: 10000, maximumAge: 30000 });
  }

  function retry() {
    load();
  }

  function focusStore(id) {
    var s = null;
    for (var i = 0; i < st.visible.length; i++) if (st.visible[i].id === id) s = st.visible[i];
    if (!s) return;
    if (st.ready) {
      st.map.setLevel(Math.min(st.map.getLevel(), 4));
      st.map.panTo(latlng(s.lat, s.lng));
    }
    select(id, false);
  }

  /* SDK를 못 쓰는 주소(미등록 도메인·차단)에서 지도 자리에 남기는 안내 */
  function sdkNoticeHtml() {
    return '<div class="pm-sdk-note" role="status">' +
      '<strong>카카오맵을 이 주소에서는 열 수 없습니다</strong>' +
      '<p>카카오 JavaScript 키에 등록된 도메인은 <b>https://moa-kr.github.io</b> 하나입니다. ' +
      '배포 주소 <a href="https://moa-kr.github.io/pokemoa/" target="_blank" rel="noopener">moa-kr.github.io/pokemoa</a>에서 열면 ' +
      '카카오맵 지도와 실제 편의점 4사 매장이 표시됩니다.</p>' +
      '<p>아래 매장 목록은 내장된 실제 좌표 스냅샷(2026-11-17)으로 계산한 값이라 그대로 확인할 수 있습니다.</p>' +
      '</div>';
  }

  function showSdkNotice() {
    if (!el.container) return;
    var old = el.container.querySelector(".pm-sdk-note-wrap");
    if (old) old.parentNode.removeChild(old);
    var wrap = document.createElement("div");
    wrap.className = "pm-sdk-note-wrap";
    wrap.innerHTML = sdkNoticeHtml();
    el.container.appendChild(wrap);
  }

  function init(opts) {
    el.container = opts.container;
    el.card = opts.card;

    ensureKakao(function (ok) {
      if (!ok) {
        st.sdkError = true;
        st.ready = false;
        st.loading.tiles = false;
        showSdkNotice();
        emit("pokemoa:loading", { active: false, phase: "error", message: "카카오맵 SDK를 불러오지 못했습니다", progress: 0 });
        emit("pokemoa:sdk-error", {
          message: "카카오맵을 이 주소에서 열 수 없어 내장 실제 좌표 스냅샷으로 표시합니다. 배포 주소(moa-kr.github.io/pokemoa)에서는 카카오맵이 정상 동작합니다."
        });
        setRegion(st.regionId);
        return;
      }
      buildMap();
      setRegion(st.regionId);
    });

    document.addEventListener("keydown", function (e) {
      if (e.key === "Escape" && st.selectedId) closeCard();
    });

    return API;
  }

  var API = {
    init: init,
    setRegion: setRegion,
    setPoint: setPoint,
    searchPlaces: searchPlaces,
    setBrand: setBrand,
    setProduct: setProduct,
    setStockOnly: setStockOnly,
    setRadius: setRadius,
    locate: locate,
    retry: retry,
    focusStore: focusStore,
    closeCard: closeCard,
    getState: function () { return st; },
    getVisible: function () { return st.visible.slice(); },
    applyRelay: applyRelay,
    clearRelay: clearRelay,
    invalidate: function () { if (st.ready && st.map.relayout) { try { st.map.relayout(); } catch (e) {} } }
  };
  return API;
})();
