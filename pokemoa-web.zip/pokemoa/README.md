# 포켓몬카드모아 (PokemonCardMoa) — 포켓몬 카드 정가·입고·재고 허브

포켓몬 카드 **MEGA 확장팩 「30th CELEBRATION」** 기준으로 정가 구매처, 추첨·입고 일정,
편의점 4사 매장을 실제 지도에서 찾는 「동네 찾기」, 정가 구매처 보드, 추첨·입고 일정,
수록 카드 도감과 구매 가이드를 한 페이지에 모은 정적 사이트입니다.
프레임워크 없이 HTML/CSS/JS로 동작하며, 지도는 **카카오맵 JavaScript SDK**, 주변 매장은 **카카오 장소 검색(Places)** 으로 조회합니다.
로고는 패밀리 브랜드(복지모아)의 벤토 그리드 심볼 형태를 그대로 쓰고 색만 포켓몬카드모아 브랜드(네이비 + 옐로)로 바꿨습니다.

- **배포 주소**: `https://moa-kr.github.io/pokemoa/` — 2026-11-18 GitHub 계정명을 `bokjinabi` → `moa-kr`로 바꾸면서 Pages 주소도 옮겼습니다(같은 저장소 `moa-kr/pokemoa`). 이전 주소 `https://bokjinabi.github.io/pokemoa/` 는 404이므로 canonical·og:url·JSON-LD·sitemap·robots는 새 주소를 씁니다.
- 데이터 기준일: 2026-11-17 (지도 스냅샷도 같은 날짜)
- 대상 뷰포트: 모바일 390×844, 데스크톱 1280×800 (그 외 반응형)
- **v2 변경**: 첫 화면을 「동네에서 찾기」(실제 지도)로, 정가 구매처를 2번 탭으로 이동. SVG 약도 → 실제 OSM 지도 + 실시간 주변 매장 조회 + 로딩 UI
- **v2.1 추가**: 매장 목록 10곳 + `더보기` 접이식, 반경 20km(지방 전용·`out center 100` 상한), 구매처 카드별 실제 상품·검색 페이지 링크, 일정·입고 탭의 지난 기록 접기
- **v3 변경**: 지역 선택을 **전국 17개 시·도 · 55개 지역**으로 확장. `시/도` + `시/군/구` 2단 드롭다운 + **동네 이름 검색**. 지역별 `allow20` 메타데이터로 도심(5km까지)과 지방·외곽(20km까지)을 구분하고, 내장 OSM 스냅샷도 전국 55개 지역·반경 3km로 다시 받았습니다
- **v3.1 변경**: 지도를 **편의점 4사 전용**으로 정리(4사 외 업종·브랜드는 필터·쿼리·스냅샷에서 제외, Overpass 쿼리는 `shop=convenience`만). 매장 목록·지도 카드에 **취급·재고 카드 상품명 태그**(30th CELEBRATION · 입고 / 배틀 파트너즈 · 소량 / 확인 필요 / 최근 입고 품절)를 표시하고, 툴바에 **카드 상품 필터**를 추가했습니다
- **v3.2 변경(PokeConv 스타일)**: 지도를 **라이트·저채도 스타일**(OSM 타일 + grayscale 필터)로 정돈하고, 둥근 핀 마커를 **상태 말풍선(알약) 마커**로 교체(`CU · 입고 2종` / `확인` / `없음`, 넓게 볼 때는 `18곳` 클러스터). 상단의 카드 7종 필터 줄과 브랜드 칩 줄을 없애는 대신 **편의점 4사별 현황 요약 바**(전체·GS25·CU·세븐일레븐·이마트24, 클릭하면 그 브랜드만)와 **정렬 드롭다운(재고 우선/가까운 거리순)**, **`재고 있는 매장만` 토글**을 넣었습니다. 매장 카드·지도 팝업은 **개소별 보유 카드**가 주인공이 되도록 정리
- **v3.3 변경(세트별 도감·가이드)**: 「도감·가이드」 탭을 30th CELEBRATION 단일 세트에서 **포켓몬카드모아에 수록된 9개 상품(30th CELEBRATION · 어비스아이 · 블랙볼트 · 로켓단의 영광 · 열풍의 아레나 · 배틀 파트너즈 · 테라스탈 페스타 ex · 초전 브레이커 · 스타터 세트)** 으로 확장. 상단 **세트 선택 칩**으로 세트를 고르면 세트 요약(발매일·구성·정가·공식 링크) · **정가 vs KREAM 시세 비교표** · **리셀 프리미엄 계산기 기준 정가** · **수록 카드 도감(검색·레어도 필터)** 이 그 세트 기준으로 즉시 바뀝니다. 홈의 인기 카드팩 카드를 누르면 해당 세트 도감으로 바로 이동합니다
- **v3.4 변경(쿠팡 파트너스 슬롯 연동)**: 도감·가이드 하단 제휴 슬롯(`coupang-supplies`)을 **실제 제휴 상품 카드**로 교체했습니다. 탑로더+슬리브 세트 상품 이미지를 **로컬 자산 `assets/coupang-supplies.jpg`**로 저장해 핫링크 차단 없이 뜨게 했고, 이미지·버튼 모두 `https://link.coupang.com/a/iKC6PvZjtQ`(`target="_blank" rel="noopener noreferrer sponsored"`)로 연결됩니다. 카드 하단에 쿠팡 파트너스 대가성 문구를 그대로 넣었습니다(`coupang-30th` 슬롯은 링크 교체 대기)
- **v3.5 변경(제휴 카드 가격 문구 제거)**: 제휴 상품 카드 본문에서 가격·할인 관련 문구(조회 시점 기준가·정가·쿠폰 적용가를 적고 `쿠폰·배송 조건에 따라 달라질 수 있습니다`로 덧붙이던 두 문장)를 삭제해 **가격을 표기하지 않습니다**. 본문은 상품 설명과 `최신 가격과 배송 조건은 쿠팡 상품 페이지에서 확인해 주세요.` 안내만 남겼습니다 — 쿠폰가·배송비는 수시로 바뀌어 정적 페이지에 적어 두면 오래된 가격이 노출되므로, 가격은 쿠팡 상품 페이지에서만 확인하도록 안내합니다.
- **v3.6 변경(도감 4장 접기 + 파트너스 위젯)**: ① 「도감·가이드」의 `수록 카드와 레어도` 목록이 모바일에서 길어지지 않도록 **처음 4장만 보여 주고** 아래에 `더보기 (N장 더 보기)` / `접기` 토글 버튼을 넣었습니다(4장 이하인 세트·검색 결과에서는 버튼 자동 숨김, 세트 칩을 바꾸면 다시 4장 상태로 리셋). ② 제휴 슬롯은 손으로 만든 상품 카드 대신 **쿠팡 파트너스 공식 상품 배너 위젯 `<iframe>`**(`https://coupa.ng/cq5BV0`, 120×240, `scrolling="no"`, `referrerpolicy="unsafe-url"`, 모바일·데스크톱 가운데 정렬)으로 교체했습니다 — 카드 상단 `쿠팡 파트너스 · 제휴 상품` 라벨과 하단 대가성 문구는 그대로 두고, 금액 표기는 없습니다(배너 안내 문구는 쿠팡이 내려주는 값).
- **v3.7 변경(FAQ 3개 접기 + 파트너스 위젯 2열)**: ① 「구매 전에 가장 많이 묻는 것들」 FAQ를 **처음 3문항만 보이고** 아래 `더보기 (N개 더 보기)` / `접기` 토글로 나머지를 펼치게 바꿨습니다(도감 더보기 버튼과 같은 점선·네이비 톤, 3문항 이하이면 버튼·토글 자동 숨김, `접기` 시 FAQ 머리로 부드럽게 스크롤, 펼침 상태에서 다시 접으면 열려 있던 항목은 닫힘). ② 도감·가이드 하단 제휴 슬롯을 **120×240 위젯 2개 가로 2열**(`display:flex; flex-wrap:nowrap; justify-content:center; gap:12px`)로 바꿔 왼쪽 1번 `https://coupa.ng/cq5BV0`, 오른쪽 2번 `https://coupa.ng/cq5DGN`이 모바일 390px에서도 **가로 넘침 없이 한 줄**로 나란히 놓입니다(320px 화면용으로 카드 패딩·gap·슬롯 폭을 줄이는 미디어 쿼리 포함). 슬롯은 `data-affiliate-slot="coupang-widget-1"`·`"coupang-widget-2"`로 구분해 위젯 코드가 바뀌면 해당 iframe `src`만 교체하면 됩니다. ③ 같은 2열 위젯 카드를 「정가 구매처」 탭 중간(`data-affiliate-card="coupang-30th"`)에도 그대로 넣었습니다 — 기존 `30th CELEBRATION 최저가 확인` 플레이스홀더·`쿠팡에서 시세 보기` 토스트 버튼을 없애고 `쿠팡 파트너스 · 제휴 상품` 라벨, 2열 위젯(`coupang-30th-widget-1/2`), 하단 대가성 문구로 도감·가이드와 동일하게 맞췄습니다.

- **v3.8 변경(집 태블릿 실재고 중계)**: 「동네에서 찾기」 상단에 **`실시간 중계` 상태 바**(연결 안 됨 / 확인 중 / 연결됨 / 응답 없음)와 `중계 연결` 버튼을 넣었습니다. 모달에서 태블릿 중계 서버 주소를 넣으면 `/health`로 확인해 localStorage에 저장하고, `?relay=https://…` 쿼리로도 자동 연결됩니다. 연결된 동안에는 조회 지역이 바뀔 때마다 `{relay}/api/nearby?lat&lng&keyword`를 호출해 **실제 매장명·실제 카드명·실제 수량(N개)**을 지도 말풍선(`CU · 3개`)·매장 카드·목록에 `실시간 재고` 배지로 표시하고, 끊기면 기존 OSM + 제보·샘플 모드로 조용히 돌아갑니다. 서버는 `relay/server.js` 단일 파일(외부 패키지 0, 포트 3100, CORS `*`, OPTIONS 204, 체인별 8초 제한 + `Promise.allSettled` 격리 + 60초 캐시)로, 이마트24·CU·세븐일레븐 앱/웹 재고 API를 조회 전용으로 호출합니다.
- **v4.0 변경(서비스명 `포케모아` → `포켓몬카드모아`)**: 검색에서 「포켓몬 카드」로 바로 걸리도록 서비스 이름을 `포켓몬카드모아`로 바꿨습니다. 화면에 보이는 이름(헤더·푸터 로고, `<title>`, `og:site_name`·`og:title`·`og:description`, `meta[name="description"]`·`keywords`·`author`, JSON-LD `WebSite.name`(+`alternateName` `카드모아`), FAQ 문항, 개인정보처리방침·이용약관, 중계 서버 안내 페이지)과 코드 주석·README를 모두 새 이름으로 통일했고, 영문 표기는 `POKEMON CARD MOA`(보조 표기 `PokemonCardMoa`)로 바꿨습니다. 배포 주소 `https://moa-kr.github.io/pokemoa/`, GA4 `G-LWRMBRD0X9`, 쿠팡 파트너스 위젯 `iframe` 2종(`coupa.ng/cq5BV0`, `coupa.ng/cq5DGN`), 중계 서버 동작, JS 전역 이름(`window.PokeMoaMap`·`window.POKEMOA_DATA`)은 그대로 두었습니다. 자산 버전은 `v=42`로 올렸습니다.
- **v4.1 변경(관리자 문의 메뉴)**: 헤더 우측 `재고 제보` 옆, 푸터 `운영·정책`, 그리고 「정가 구매처」·「도감·가이드」 탭 하단 안내 카드에 **`관리자 문의`** 진입점을 넣었습니다. 모달에서 **문의 유형**(재고·매장 정보 오류 / 정가·출시 일정 제보 / 광고·제휴 문의 / 기타) · **제목** · **내용**을 적고 **`메일 앱으로 보내기`**(`mailto:acewoni3717@gmail.com`, 제목·본문에 유형·제목·내용·보낸 페이지·시각을 담아 전송) 또는 **`운영자 이메일 복사`**(`acewoni3717@gmail.com`, `navigator.clipboard` 실패 시 `execCommand` 대체), **`문의 내용 복사`**를 쓸 수 있어 **정적 사이트 단독으로 100% 동작**합니다. 회사복지모아 서버(`https://bokjimoa.onrender.com/api/inquiries`)는 CORS가 열려 있어도 호출하지 않으며, 나중에 연동해도 위 두 경로는 그대로 둡니다. 기존 `재고 제보`는 같은 모달을 유형 `재고·매장 정보 오류`로 미리 골라 엽니다(데모 전송 안내 문구 삭제). 모바일 390px 헤더는 56px 한 줄 유지(버튼 패딩·글자 축소), 320px급에서는 헤더 버튼을 숨기고 푸터·탭 하단 카드로 진입합니다. 지도 pane의 z-index(400~999)가 페이지 스택으로 새어 나와 모달·토스트 위에 그려지던 문제를 `.map-shell { isolation: isolate }`로 정리했습니다(지도 내부 레이어링은 그대로). 자산 버전은 `v=45`로 올렸습니다.
- **v4.2 변경(AdSense 게시자 ID·ads.txt·PC 사이드 레일)**: 2026-11-18 발급받은 게시자 ID `ca-pub-2702295880931505`로 `adsbygoogle.js` 스크립트를 `index.html`(기존 주석 플레이스홀더 교체)·`privacy.html`·`terms.html` `<head>`에 넣고, 루트에 `ads.txt`(`google.com, pub-2702295880931505, DIRECT, f08c47fec0942fa0`)를 추가했습니다. 회사복지모아와 같은 방식으로 **PC 넓은 화면(≥1360px) 전용 좌·우 160×600 스카이스크래퍼 레일**(`.side-ad-rail`, `data-ad-slot="left-rail"/"right-rail"`)을 넣었습니다 — 그 폭에서만 `--wrap-w: min(1180px, 100vw - 400px)`로 본문을 줄여 좌우 여백을 확보하고, 1360px 미만에서는 `display:none !important`로 완전히 숨겨 모바일 390px 레이아웃과 가로 넘침에 영향이 없습니다. 광고 슬롯 8곳은 아직 점선 플레이스홀더이고, 승인 후 `<ins class="adsbygoogle">`로 교체하면 됩니다.
- **v4.4 변경(5km·20km 다점 격자 조회·마커)**: 카카오 장소 검색이 한 번에 **최대 45건**만 돌려주기 때문에, 포항 북구처럼 편의점이 밀집한 곳에서는 반경을 3→5→20km로 넓혀도 **중심 2km 안의 같은 41곳**만 조회되고 외곽 매장이 통째로 빠지던 문제를 고쳤습니다. 이제 반경별로 여러 지점에서 나눠 조회해 합칩니다 — `~3km`는 기존대로 중심 3페이지(1초 안팎), `5km`는 중심(반경 3km·2페이지) + 동·서·남·북 2.8km 지점(반경 2.6km·2페이지), `20km`는 중심(반경 5km·2페이지) + 반경 5km 고리·8방위(반경 4km·1페이지) + 반경 13km 고리·8방위(반경 7km·1페이지)를 **병렬 조회**한 뒤 `id` 중복 제거 → 실제 거리로 반경 필터 → 빠진 브랜드는 `keywordSearch`로 보충합니다. 포항 북구 기준 **3km 41곳 → 5km 116곳 → 20km 185곳**(GS25 60·CU 72·세븐일레븐 32·이마트24 21)으로 늘었습니다. 마커 상한도 5km 120곳·20km 200곳(기존 90·100)으로 넓혔습니다. 지도는 **5km를 골라도 반경 원에 맞춰 자동 축소**(`fitRing`, 1·3km로 좁힐 때는 기본 확대 복귀)되고, 마커는 줌에 따라 3단으로 바뀝니다 — 가까이는 브랜드 말풍선, **5km는 브랜드 칩·점**(칩이 겹치는 자리는 숫자만 담은 26px 원), **20km는 지역별 `N곳` 묶음**. 20km 클러스터 칸 크기는 150/110/80px → **85/58/40px**로 줄이고, 거의 같은 자리에 겹치는 묶음만 하나로 합쳐(`mergeNearby`) `41곳` 한 덩어리 대신 **도심 + 흥해·청하·송도·유강·동해·월포·구룡포·호미곶·경주강동 등 15개 묶음**이 반경 전역에 퍼져 보입니다. 반경 구간(3·5·20km)이 바뀌면 다시 조회해 20km 결과를 5km 보기에 그대로 쓰지 않습니다. `SEARCH_TIMEOUT`은 6초 → 8초. 자산 버전은 `v=49`.
- **v4.3 변경(카카오맵 전환)**: 지도 엔진을 Leaflet + OpenStreetMap 타일 + Overpass API에서 **카카오맵 JavaScript SDK(`dapi.kakao.com/v2/maps/sdk.js?appkey=…&libraries=services&autoload=false`, `kakao.maps.load` 초기화) + 카카오 장소 검색(Places)** 으로 전면 교체했습니다. 주변 매장은 `categorySearch('CS2', { location, radius, sort: DISTANCE, page: 1~3 })` **3페이지 병렬 조회(최대 45건)** 로 받고, 카테고리 결과에 없는 브랜드는 `keywordSearch('GS25'/'CU'/'세븐일레븐'/'이마트24')`로 1페이지씩 **보충 조회**해 편의점 4사를 빠짐없이 채웁니다. 해외 Overpass 왕복이 사라져 조회가 **1초 안팎**(Overpass 8초 제한·504 타임아웃)으로 끝납니다. 말풍선(알약) 마커·`N곳` 클러스터·반경 원·내 위치 마커·브랜드/상품/재고 필터·집 태블릿 중계(`relay`) 병합은 `kakao.maps.CustomOverlay`·`kakao.maps.Circle`로 그대로 재구현했고, 줌↔카카오 level 매핑(level = 20 − zoom), 동네·역 이름 검색도 `kakao.maps.services.Places.keywordSearch`로 즉시 조회합니다. 카카오 SDK는 **등록 도메인 `https://moa-kr.github.io`에서만** 지도를 그리므로, 그 밖의 주소(`file://`·미등록 프리뷰)에서는 지도 자리에 안내 카드를 띄우고 **내장 실제 좌표 스냅샷(2026-11-17)** 으로 목록·집계·배지를 그대로 동작시킵니다(오류로 멈추지 않음). 함께 ① 지도 범례를 `bottom:30px`(모바일 28px)로 올려 카카오 로고·저작권 표기를 가리지 않게 했고 ② 「상태 안내」 카드가 좁은 칸에서 세로로 찌그러지던 레이아웃을 이름표 위·본문 아래로 정리했습니다. 자산 버전은 `v=48`.

> 타일 참고: 브리프의 CARTO Positron(`basemaps.cartocdn.com/light_all`)은 2026-11 확인 시 **API 키가 없으면 `API KEY REQUIRED` 워터마크 타일**이 내려와 쓸 수 없었습니다. 그래서 OSM 표준 타일에 저채도·밝기 필터를 걸어 Positron과 같은 라이트 느낌을 냈고(한국어 지명 그대로), 타일 서버가 막히면 OSM 독일 미러로 자동 대체합니다.

---

## 1. 로컬에서 보기

```bash
cd pokemoa
python3 -m http.server 8080
# 브라우저에서 http://localhost:8080/ 열기
```

`file://`로 열어도 탭·검색은 동작합니다. 지도는 카카오맵 JavaScript SDK와 카카오 장소 검색을 쓰므로
인터넷 연결이 필요합니다. 다만 카카오 JavaScript 키에 등록된 도메인은 `https://moa-kr.github.io` 하나라서
`file://`·`localhost` 같은 미등록 주소에서는 지도 대신 **내장 실제 좌표 스냅샷 안내 카드**가 뜨고 목록·집계는 그대로 동작합니다.
지도를 실제로 보려면 배포 주소(`https://moa-kr.github.io/pokemoa/`)로 열어 주세요.

## 2. 폴더 구조

```
pokemoa/
├─ index.html                # 동네 찾기 / 정가 구매처 / 일정·입고 / 도감·가이드 (해시 라우팅)
├─ pokemoa-preview.html      # 위 파일 + CSS/JS를 한 파일로 합친 미리보기
├─ privacy.html              # 개인정보처리방침 (단독 URL — AdSense 심사용)
├─ terms.html                # 이용약관 (단독 URL)
├─ robots.txt
├─ ads.txt                   # AdSense 게시자 인증(google.com, pub-2702295880931505)
├─ sitemap.xml
├─ assets/
│  ├─ css/style.css          # 전체 스타일 (모바일 우선)
│  └─ js/
│     ├─ data.js             # 지역·좌표 스냅샷(대체용)·카드·일정·구매처 데이터
│     ├─ map.js              # 카카오맵 SDK + 카카오 장소 검색 지도 엔진 (+ 중계 실재고 반영)
│     └─ app.js              # 탭·필터·검색·모달·계산기 (+ 실시간 중계 연결 UI)
├─ relay/
│  └─ server.js              # 집 태블릿(Termux)용 무의존 실재고 중계 서버 (Node 20+, 포트 3100)
├─ screenshots/              # 검증 스크린샷
└─ pokemoa-web.zip           # 배포용 압축본 (index/privacy/terms/assets/relay/robots/sitemap/ads.txt/README)
```

## 3. 주요 기능

### 1번 탭 — 동네에서 찾기 (v2 첫 화면)
- **실제 지도**: 카카오맵 JavaScript SDK(`autoload=false` → `kakao.maps.load`) 타일 (도로·건물·지명·카카오 장소 POI 그대로)
- **지역 선택 (전국)**: `시/도`(17개) → `시/군/구` 2단 드롭다운과 **동네 이름 검색**(예: 판교, 해운대, 제주시). 기본값은 포항 북구(환호동). 지역을 바꾸면 지도가 그 좌표로 이동하고 주변 매장을 새로 조회합니다. 55개 지역의 중심 좌표는 OpenStreetMap(Nominatim) 기준이며, 목록에 없는 동네·역·건물 이름은 **카카오 장소 검색**으로 그 자리에서 찾아 지도를 엽니다
- **실시간 주변 매장**: 지역 선택 또는 **내 위치로 찾기**(브라우저 Geolocation) →
  카카오 장소 검색 `categorySearch('CS2')`를 반경에 맞게 나눠 **병렬 조회**하고(3km 이하는 중심 1곳 3페이지, 5km·20km는 중심 + 방위 오프셋 격자), `id` 중복 제거·실제 거리 필터 후 빠진 브랜드는 브랜드별 `keywordSearch`로 보충해 **편의점 4사(GS25·CU·세븐일레븐·이마트24)**만 남겨 표시(그 밖의 브랜드·업종은 제외). 3km 조회는 보통 1초 이내, 5km·20km 격자 조회는 2~4초(8초 넘으면 스냅샷으로 먼저 표시)
- **로딩 UI**: 카카오맵 지도 → 카카오 장소 검색 2단계 진행률 바 + 스피너 + "실제 지도와 주변 매장 위치를 불러오는 중..." 안내,
  매장 목록은 스켈레톤 카드로 자리 표시
- **폴백**: 카카오 장소 검색이 8초 안에 끝나지 않거나 쿼터·차단·미등록 도메인으로 실패하면 내장 실제 좌표 스냅샷(2026-11-17, 전국 55개 지역·반경 3km OSM 조회분)으로 자동 전환.
  상단 배지가 `실시간 조회` / `내장 스냅샷` 상태를 그대로 표기하고 `실시간 다시 조회` 버튼 제공
- **매장 목록은 처음 10곳만** 표시하고 `더보기 (N개 더 보기)`로 펼침(다시 누르면 접힘). 지역·브랜드·반경 필터가 바뀌면 10곳 접힘 상태로 초기화
- 브랜드 필터는 **편의점 4사별 현황 요약 바**(전체·GS25·CU·세븐일레븐·이마트24, 각 `N곳`·`재고 N곳`)로 통합 — 카드를 누르면 그 브랜드만, 한 번 더 누르면 전체. 반경 1/3/5/**20km** + 상태별 카운트 + **정렬(재고 우선/가까운 거리순)** + **`재고 있는 매장만` 토글**
- **20km 반경**: 지역별 `allow20` 값으로 나뉩니다. 서울·인천·경기 주요 도심(수원·성남·용인·고양·부천)·광역시 도심(부산·대구·대전·광주·울산)은 5km까지이며 20km 버튼이 비활성화되고 `도심은 5km까지 지원` 안내와 함께 자동으로 5km로 전환됩니다. 포항·경주·경남·강원·충청·전라·제주와 경기 외곽(화성·평택·의정부)·세종은 20km가 활성화됩니다. 20km 조회는 카카오 장소 검색 반경 상한(20,000m)을 그대로 쓰고 가까운 200곳까지 지도·목록에 올림
- **매장별 취급·재고 카드명**: 목록 카드와 지도 팝업에 `30th CELEBRATION · 입고`, `배틀 파트너즈 · 소량`, `… · 확인 필요`, `최근 입고 품절` 같은 상품명 태그를 표시. 재고 있음 매장은 입고/소량, 확인 필요 매장은 확인 필요, 재고 없음 매장은 품절/미입고와 `최근 입고 품절` 머리표로 구분
- **지도 마커**: 상태가 바로 읽히는 말풍선(알약) 마커 — 재고 있음은 브랜드 색 `CU · 입고 2종`, 확인 필요·없음은 화이트/그레이 `확인`·`없음`. 넓게 볼 때는 2단으로 줄입니다 — **5km(level 7~9)** 는 작은 브랜드 칩·점(칩이 겹치는 자리는 숫자만 담은 26px 원), **20km(level 10 이상)** 는 같은 구역 매장을 `18곳 · 재고 6` 묶음으로 표시하고 누르면 그 구역으로 확대
- **지도 범례**: 지도 하단에 `내 위치 · 재고 있음 · 확인 필요 · 없음`
- 마커/목록 양방향 연동, 마커 선택 시 지도 하단 고정 카드(상태·거리·관측 시각·**보유 카드**·네이버 지도 링크)
- **정직한 고지**: 매장 위치·이름은 카카오맵 실제 장소 데이터, 재고 상태(재고 있음/확인 필요/없음)와 취급 카드 상품명은 편의점 앱 API 미연동으로 제보·샘플 기반임을 배지·카드·목록·`샘플 재고` 칩으로 표시

#### 전국 55개 지역 (v3)

| 시·도 | 지역 | 20km |
| --- | --- | --- |
| 서울 | 강남·역삼, 홍대·마포, 노원·강북, 잠실·송파, 여의도·영등포, 종로·명동 | ✗ (5km) |
| 부산 | 서면·부산진, 해운대, 남포·중구, 사상·북구 | ✗ (5km) |
| 대구 | 동성로·중구, 수성구, 달서구 | ✗ (5km) |
| 인천 | 송도·연수, 부평, 구월·남동 | ✗ (5km) |
| 광주 | 충장로·동구, 상무·서구 | ✗ (5km) |
| 대전 | 둔산·서구, 유성구 | ✗ (5km) |
| 울산 | 삼산·남구, 중구 | ✗ (5km) |
| 세종 | 세종시청·보람동 | ○ |
| 경기 | 수원·영통, 성남·판교, 용인·수지, 고양·일산, 부천 (5km) / 화성·동탄, 평택, 의정부 (20km) | 일부 |
| 강원 | 춘천, 원주, 강릉 | ○ |
| 충북 | 청주, 충주 | ○ |
| 충남 | 천안, 아산 | ○ |
| 전북 | 전주, 익산, 군산 | ○ |
| 전남 | 순천, 여수, 목포 | ○ |
| 경북 | 포항·북구(환호동, 기본), 포항·남구, 경주, 구미, 안동 | ○ |
| 경남 | 창원·성산, 김해, 진주, 양산 | ○ |
| 제주 | 제주시, 서귀포시 | ○ |

### 2번 탭 — 정가 구매처 (기존 홈)
- **채널별 실제 상품·검색 페이지 연결**: 포켓몬스토어 30th 상품(m6a), SSG 상품(1000881834004), G마켓 상품(4856436280), 티씨지박스 30th 1BOX(22970), 롯데ON 포켓몬카드 검색, CU 상품 검색, GS25, 세븐일레븐, 이마트24
- 히어로: 정가(1팩 3,500원 / 1박스 20팩 70,000원)와 KREAM 미개봉 시세 안내(2026-11-17 · 슈링크 76,000원 / 논슈링크 72,000원, 배송비·수수료 별도)
- **정가 구매처 보드 6개 채널**: 포켓몬스토어(추첨), SSG 공식인증샵(70,000+3,000), G마켓 공식인증샵,
  티씨지박스, 토이저러스·롯데마트, 편의점 4사 — 실제 URL 링크 포함
- 인기 카드팩 트렌드 4종, 오늘의 체크 포인트, 최근 입고 타임라인(샘플)

### 일정 · 입고
- **오늘(KST) 이후 일정만 기본 표시**: 지난 추첨·입고 기록은 `지난 일정 보기 (N건)` 접이식으로 숨김, 캘린더도 오늘 이후 입고일만 표시(`지난 입고일 보기` 토글로 확인)
- 포켓몬스토어 1·2차 추첨, FUTURISTIC BOX, 편의점 4사 입고 일정 타임라인
- 요일별 입고 체크 가이드, 11월 입고 캘린더(예상 샘플), 최근 입고 피드, 공지 확인처 링크

### 도감 · 가이드
- **세트 선택 칩 9종**: 30th CELEBRATION(M6a) · 어비스아이(M5) · 블랙볼트(SV11B) · 로켓단의 영광(SV10) · 열풍의 아레나(SV9a) · 배틀 파트너즈(SV9) · 테라스탈 페스타 ex(SV8a) · 초전 브레이커(SV8) · 스타터 세트(MEGA 스타터 세트 ex 「이브이 ex」). 모바일 390px에서는 가로 스크롤, 720px 이상에서는 줄바꿈
- **세트 요약 패널**: 발매일 · 구성(1팩 매수/1박스 팩 수) · 공식 정가 · 수록 카드 수 · KREAM 즉시구매가 + 공식 제품 페이지·KREAM 링크
- **정가 vs 리셀 비교표**: 선택 세트의 정가를 기준으로 KREAM 한글판 1박스 즉시구매 최저가를 팩당 단가·정가 대비 %로 환산(스타터 세트는 `세트 가격/세트당 단가`로 자동 전환)
- **리셀 프리미엄 계산기**: 기준 정가가 선택 세트의 박스 정가로 자동 전환(입력값은 유지한 채 새 기준으로 재계산)
- **수록 카드 도감**: 세트별 대표 카드 10~34장(30th는 기존 34장 전체 유지, 나머지는 SAR·AR·SR·UR·MUR·BWR 등 대표 카드). 이름·번호 검색 + **세트에 실제로 있는 레어도만 칩으로 생성**, 카드 클릭 → 상세 모달
- 미개봉(슈링크) 체크리스트 7항목, 가품·재포장 주의 신호, FAQ 8문항 아코디언(처음 **3문항 + `더보기 (5개 더 보기)` / `접기`**, v3.7)은 공통 섹션으로 하단 유지

> 세트별 데이터는 공식 제품 정보(pokemoncard.co.kr)의 정가·구성·발매일과 KREAM 한글판 1박스 즉시구매 최저가(2026-11-17 확인)를 `assets/js/data.js`의 `SETS` 배열에 정리했습니다. 카드 번호·레어도는 공식 카드검색과 TCGHeart·리치몬 목록을 대조해 확인한 카드만 실었고, 전체 카드 목록이 아니라 대표 카드만 담았습니다(카드 도감 설명에 명시).

### 수익화 · 운영 페이지
- AdSense 슬롯 8곳: `home-top-banner`, `home-infeed-1`, `map-bottom`, `schedule-bottom`,
  `guide-bottom`, `mobile-sticky`, 그리고 PC 넓은 화면 전용 좌·우 스카이스크래퍼 `left-rail`·`right-rail`(각 160×600, 1360px 이상에서만 표시) — 모두 점선 플레이스홀더 + `data-ad-slot` 속성
- 쿠팡 파트너스 슬롯 2곳(대가성 문구 포함) — 둘 다 **같은 2열 위젯 카드**로 통일(v3.7): 「도감·가이드」 하단 `coupang-supplies`(`coupang-widget-1` = `https://coupa.ng/cq5BV0` / `coupang-widget-2` = `https://coupa.ng/cq5DGN`)와 「정가 구매처」 중간 `coupang-30th`(`coupang-30th-widget-1` / `-2`, 같은 위젯 코드) — 각 120×240, `flex-wrap:nowrap`·`gap:12px`, 모바일 390px에서도 한 줄
- 푸터 모달: 소개 / 개인정보처리방침 / 이용약관 / 관리자 문의(메일 보내기·이메일 복사)
- **Google Analytics 4**: `G-LWRMBRD0X9` — `index.html`·`privacy.html`·`terms.html` `<head>`에 gtag 스니펫, `assets/js/app.js`의 `trackEvent()` 래퍼로 주요 행동 이벤트를 전송(v3.9)
  - `tab_view`(`tab`, `entry`: initial/switch) · `region_search`(`region`, `region_name`, `radius_km`)
  - `store_outbound_click`(`store_name`, `url`) · `dex_set_select`(`set_id`) · `dex_expand`(`expanded`) · `faq_expand`(`expanded`)
  - `affiliate_interact`(`slot`, `action`: click/focus — iframe 내부 클릭은 cross-origin이라 감지하지 못하므로 카드·슬롯 상자의 클릭·포커스만 집계)
  - `relay_connect`(`status`: online/error) · `admin_inquiry`(`method`: mailto/copy_email/copy_body, `inquiry_type`)
  - 측정 ID를 바꾸려면 HTML 3개 파일의 gtag 스니펫 `id=`와 `gtag('config', …)` 두 곳만 교체하면 됩니다.
- `privacy.html`, `terms.html` 단독 문서, `sitemap.xml`, `robots.txt`, OG/Twitter/JSON-LD(WebSite·FAQPage)

## 4. 실시간 중계 — 집 태블릿 실재고 (v3.8)

매장별 **실제 재고 수량**이 필요할 때 쓰는 선택 기능입니다. 사이트는 정적 Pages라 편의점 앱 API를 직접 부를 수 없어서,
집 태블릿이 대신 조회해 주는 작은 서버(`relay/server.js`)를 두고 지도가 그 서버를 통해 실재고를 받아 옵니다.

### 켜는 법 (태블릿 · Termux)
```bash
pkg install nodejs cloudflared        # 한 번만 (cloudflared가 안 보이면 `pkg install tur-repo` 뒤 다시)
node server.js                        # relay/ 폴더에서 — http://127.0.0.1:3100
cloudflared tunnel --url http://127.0.0.1:3100   # 출력된 https://….trycloudflare.com 이 중계 주소
```
- 서버는 **외부 npm 패키지 없이** Node 내장 모듈만 씁니다(파일 1개, `node server.js` 한 줄).
- `127.0.0.1:3100`은 태블릿 안에서만 열리는 주소라, 바깥(휴대폰)에서 쓰려면 cloudflared 같은 터널로 https 주소를 만들어 그 주소를 입력합니다.
- 같은 와이파이에서만 쓸 때는 `HOST=0.0.0.0 node server.js` 후 `http://<태블릿 IP>:3100`을 넣어도 됩니다.

### 사이트에서 연결
- 「동네에서 찾기」 상단의 **`실시간 중계`** 바 → `중계 연결` → 주소 입력 → `/health`로 확인 후 저장(localStorage).
- `https://…/pokemoa/?relay=https://xxxx.trycloudflare.com` 처럼 **쿼리로 열면 자동 저장·연결**됩니다(태블릿 홈 화면 북마크용).
- 연결된 동안 지도는 조회 지역이 바뀔 때마다 중계에 다시 물어보고, 받은 매장은 **`실시간 재고`** 배지와 `브랜드 · N개` 말풍선으로 표시됩니다.
- 중계가 꺼져 있거나 응답이 없으면 조용히 기존 **카카오맵 + 제보·샘플** 모드로 돌아가고 상태 바에 그 사실이 남습니다.

### 서버가 하는 일
| 경로 | 내용 |
| --- | --- |
| `GET /health` | `{ ok, service: "pokemoa-relay", version, time }` — 사이트가 연결 확인에 씁니다 |
| `GET /api/nearby?lat&lng&keyword` | 주변 점포의 실재고를 모아 `{ ok, relay, lat, lng, sources, stores[] }` 로 반환 |
| `GET /` | 브라우저로 열었을 때 보이는 사용 안내 |

체인별 구현(모두 **조회만** 합니다 — 주문·결제·선점 요청 없음):
- **이마트24** `everse.emart24.co.kr` — `POST /store/getNearStoreList`(주변 점포) → `POST /stock/stock/search`(상품 `pluCd`) → `GET /api/stock/v3/stock-search/store?searchPluCode&bizNoArr`(점포별 `BIZQTY`). 상품 검색은 `content-type`에 `charset=UTF-8`이 빠지면 한글 검색이 조용히 0건이 되므로 반드시 붙입니다.
- **CU** `www.pocketcu.co.kr` — `POST /api/search/rest/stock/main`(상품 `item_cd`) → `POST /api/store`(주변 점포). 앱 웹뷰 식별자 User-Agent(`…;BGFCU`)가 있어야 응답합니다. 점포별 수량 필드(`stock`)가 비어 오는 경우가 많아, **수량을 받은 점포만** 결과에 넣습니다.
- **세븐일레븐** `new.7-elevenapp.co.kr` — `GET /api/v1/auth/session/is-authenticated`까지 시도하고, 좌표가 RSA-OAEP(SHA-256)로 암호화돼 있어 공개키(`SEVEN_RSA_KEY_B64`)와 상품 코드(`SEVEN_SM_CD`)가 없으면 **그 체인만 `status:"error"`로 격리**합니다(나머지 체인 결과는 정상 반환).
- 체인 하나가 403·타임아웃이어도 전체가 죽지 않도록 `Promise.allSettled` + 체인별 8초 제한, 같은 좌표는 60초 캐시(`RELAY_CACHE_MS`).

### 확인된 한계 (2026-11-17 실측)
- 이 서버를 만든 데이터센터 회선에서는 **이마트24·세븐일레븐이 403**(각 사 WAF/Incapsula), **CU는 응답은 오지만 점포별 수량이 비어** 있었습니다. 집(한국 가정 회선)에서 이마트24가 정상 응답하는지는 태블릿에서 `curl 'http://127.0.0.1:3100/api/nearby?lat=36.0733&lng=129.3947'`으로 바로 확인할 수 있습니다.
- 응답은 `sources: { emart24: { ok, count, error? }, cu: …, seven: … }`에 체인별 상태를 그대로 담으므로, 어느 체인이 막혔는지 화면과 로그에서 바로 보입니다.

## 5. 배포 전에 바꿀 것 (중요)

1. **도메인**: 소스에는 `pokemoa.example` 플레이스홀더(`https://` + 도메인 형태)가 남아 있고, 배포본을 만드는 `tmp/pokemoa-build/deploy.sh`가 그 부분을 `https://moa-kr.github.io/pokemoa`로 일괄 치환합니다
   (`index.html`, `privacy.html`, `terms.html`, `sitemap.xml`, `robots.txt` 대상). 도메인을 또 바꾸려면 `deploy.sh`의 `LIVE` 한 줄만 고쳐 다시 실행하면 됩니다
2. **AdSense**: 게시자 ID `ca-pub-2702295880931505`(2026-11-18 발급)로 `adsbygoogle.js` 스크립트가 `index.html`·`privacy.html`·`terms.html` `<head>`에 이미 들어가 있고, 루트 `ads.txt`(`google.com, pub-2702295880931505, DIRECT, f08c47fec0942fa0`)도 배포되어 있습니다.
   남은 작업은 각 광고 슬롯 자리의 플레이스홀더를 `<ins class="adsbygoogle" data-ad-client="ca-pub-2702295880931505" data-ad-slot="…">`로 바꾸고 승인된 광고 단위 ID를 넣는 것입니다.
3. **쿠팡 파트너스**: 도감·가이드(`data-affiliate-card="coupang-supplies"`)와 정가 구매처(`data-affiliate-card="coupang-30th"`) 모두 **쿠팡 파트너스가 발급한 위젯 iframe 2개**로 구성되어 있습니다(`https://coupa.ng/cq5BV0` · `https://coupa.ng/cq5DGN`, 각 120×240, `data-affiliate-slot="…-widget-1/2"`) — 배너 상품을 바꾸려면 파트너스에서 새 위젯 코드를 받아
   `index.html`의 해당 `.affiliate-slot` 안 iframe `src`만 바꾸면 됩니다(이미지·상품명·링크는 쿠팡이 내려줍니다). 카드 본문에는 **가격을 표기하지 않습니다**(v3.5) — 배너 안의 가격은 쿠팡 위젯이 실시간으로 표시합니다.
4. **관리자 문의**: `tpl-inquiry`의 폼은 서버 없이 `mailto:acewoni3717@gmail.com` + 이메일·내용 복사로 동작합니다(v4.1).
   폼 백엔드(Formspree·Google Forms·`/api/inquiries` 등)를 붙이려면 `assets/js/app.js`의 `initInquiryForm()` 제출 핸들러에
   호출을 더하고, `mailto:`·복사 버튼은 실패 대비로 남겨 두세요. 문의처 이메일은 `index.html`(`INQUIRY_EMAIL` 값·모달·푸터)과
   `privacy.html`에 함께 적혀 있습니다.
5. **실데이터**: 매장 위치는 **카카오 장소 검색(Places) 실시간 조회** + 실패 시 `assets/js/data.js`의 `osmSnapshot`(2026-11-17 스냅샷)을 사용합니다.
   스냅샷은 `python3` 스크립트로 응답을 다시 받아 갱신하면 됩니다. 재고 상태는 아직 샘플(`sampleStatus`)이므로
   편의점 앱 재고 API 또는 이용자 제보 DB로 교체하고, 관측 시각·상태를 서버에서 내려주세요.
5-1. **지도 정책**: 카카오맵 JavaScript SDK(카카오디벨로퍼스 앱 `포켓몬카드모아`, ID `1655851`)와 카카오 장소 검색을 사용합니다.
   JavaScript 키(`63b35e228dacdcc4d0e31f83a7738f22`)는 공개 키라 소스에 두어도 되지만, **JS SDK 도메인에 배포 도메인을 등록**해야 지도가 뜹니다(현재 `https://moa-kr.github.io`).
   카카오맵 API는 일간 무료 쿼터가 있어 트래픽이 커지면 카카오디벨로퍼스에서 쿼터·요금제를 확인하세요.
6. **카드 이미지**: 저작권 문제로 공식 카드 이미지를 사용하지 않고 CSS 그라데이션 아트로 대체했습니다.
   이미지 사용 권한을 확보한 경우에만 교체하세요.
7. **광고 정책**: 만 14세 미만 이용자 대상이 아니며, 카드 도박·현금 거래를 조장하는 문구는 넣지 않았습니다.

## 6. 검증 기록

- **v4.4 확인 항목(2026-11-18 라이브 `https://moa-kr.github.io/pokemoa/`, 자산 `v=49`, 커밋 `87d34b4`, GitHub Pages `built`)**:
  ① 포항 북구 반경별 매장 수: **3km 41곳 → 5km 116곳 → 20km 185곳** (브랜드 4사 모두 포함 — 5km GS25 46·CU 42·세븐일레븐 19·이마트24 9 / 20km GS25 60·CU 72·세븐일레븐 32·이마트24 21, 재고 63·확인 92·없음 30). 개선 전에는 3·5·20km 모두 **41곳**으로 같았습니다.
  ② 조회 계획: `searchPlan()`이 5km에서 10회, 20km에서 18회 `categorySearch('CS2')`를 병렬 호출하고, `id` 중복 제거 후 `meters(center,row) <= radius`로 다시 거릅니다. 20km 고리 격자는 0~20km 구간을 고르게 채웁니다(2km 단위 33·24·50·20·15·16·11·16·6·4곳).
  ③ 5km 자동 맞춤: `setRadius(5000)` → `fitRing()`으로 level 8(반경 원 전체가 화면 안)이 되고, 마커는 브랜드 칩 7개 + 숫자 원 19개(116곳 전부 반영)로 고르게 표시. 1·3km로 좁히면 기본 확대(level 5)로 복귀.
  ④ 20km 마커: level 10에서 클러스터 칸 58px → `41곳` 한 덩어리 대신 **15개 묶음**(도심 84, 송도 29, 문덕 15, 유강 13, 청하 10, 동해 7, 신항만·칠포 5, 흥해 4, 호미곶 4, 서포항IC·기계 3, 구룡포 3, 신항만 3, 블루밸리 3, 경주강동 2 등)이 반경 전역에 퍼져 표시.
  ⑤ 반경 구간 재조회: 20km → 5km 전환 시 5km 계획으로 다시 조회해 **116곳** 유지(20km 결과를 그대로 쓰면 71곳으로 줄어 보이던 문제 수정), 1km는 7곳.
  ⑥ 오류·화면: 반경 전환·필터·카드 전 과정 JS 오류·미처리 예외 **0건**. 스크린샷 `downloads/pokemoa-5km-fixed.png`(5km, 116곳), `downloads/pokemoa-20km-fixed.png`(20km, 185곳).
  ⑦ 이 실행 환경의 네트워크 지연으로 콜드 로드에서 카카오 SDK가 9초를 넘겨 한 번 `kakao-sdk-unavailable` 스냅샷 폴백이 발생했고(화면은 정상 동작), 새로고침 후 실시간 조회로 복귀.
- **v4.3 확인 항목(2026-11-18 라이브 `https://moa-kr.github.io/pokemoa/`, 자산 `v=48`, 커밋 `de216c5`, GitHub Pages `built`)**:
  ① 카카오맵 JavaScript SDK 4.5.31이 `dapi.kakao.com/v2/maps/sdk.js?appkey=…&libraries=services&autoload=false`로 로드되고 `kakao.maps.load` 콜백에서 지도가 생성됨(등록 도메인 `https://moa-kr.github.io`), 카카오 타일 256px 이미지 정상 렌더(깨진 타일 0장), 확대/축소 컨트롤·`Kakao 맵으로 이동` 로고·`250m` 축척 표기 정상.
  ② 포항 북구 3km 기본 조회: 배지 `실시간 조회 · 카카오맵 주변 편의점 4사 41곳`, 브랜드 4사 모두 표시(GS25 17 · CU 17 · 세븐일레븐 5 · 이마트24 2 / 재고 12 · 확인 25 · 없음 4), 말풍선 마커 41개·목록 10곳+`더보기 (31개 더 보기)`.
  ③ 조회 방식: `Places.categorySearch('CS2', {location, radius, sort: DISTANCE, page: 1~3, size: 15})` 3페이지를 **병렬** 호출(각 15건, `totalCount` 45), 빠진 브랜드는 `keywordSearch` 1페이지로 보충. 같은 세션 재조회 응답 **543ms · 1,822ms**(2회 측정)로 기존 Overpass 8초 제한·504 타임아웃이 사라짐. 최초 콜드 로드에서 SDK·검색이 5~14초 걸린 것은 이 실행 환경의 네트워크 지연(index.html 응답 자체가 6초)이며, 재조회는 1초 안팎.
  ④ 반경·도심: 20km 선택 시 `kakao.maps.Circle` 반경 전체로 자동 맞춤 + 클러스터 `41곳` 1개, 서울 강남은 도심 판정으로 5km 자동 전환·20km 버튼 비활성·`도심은 5km까지 지원` 안내와 함께 45곳, 부산 해운대 45곳·문현동(카카오 장소 검색) 43곳 모두 4사 포함.
  ⑤ 동네·역 검색: 내장 55개 지역 결과 아래에 **카카오 장소 검색 결과**(예: `문현동` → `문현동곱창골목`·`황령산 유원지 생태숲` 등 6건, 주소 포함)가 붙고, 선택하면 지도 중심이 그 좌표로 이동해 반경 5km 재조회(43곳) + 시·군·구 드롭다운에 `검색: 문현동곱창골목` 표시, GA4 `region_search` 이벤트(`region=kakao-place`) 전송.
  ⑥ 말풍선 마커·카드: `CU 환호해맞이그린빌점` 클릭 → 카드(브랜드 배지·주소 `경북 포항시 북구 삼호로 415`·364m·`재고 있음`·`샘플 재고`·관측 시각·전화 `054-256-8200`·보유 카드 3종 태그·네이버 지도 링크)가 열리고, 목록 카드와 양방향 하이라이트 동기화. 필터: CU 17곳, `재고 있는 매장만` 12곳, `재고 우선` 정렬 유지.
  ⑦ 미등록 주소 폴백: 카카오 SDK를 못 쓰는 환경에서는 지도 자리에 `카카오맵을 이 주소에서는 열 수 없습니다` 안내 카드를 띄우고 **내장 좌표 스냅샷(포항 북구 18곳)** 으로 목록·집계·배지가 그대로 동작하며 오류로 멈추지 않음(DOM·SDK 스텁 하네스 `tmp/pokemoa-kakao-test.py`로 스냅샷 경로·SDK 실패 경로·필터·반경·`setPoint`·카드 열기까지 확인, 리스너 예외 0건).
  ⑧ 오류: 로드·지역/반경/브랜드/재고 필터·장소 검색·카드 열기 전 과정에서 JS 오류·미처리 예외 0건, 자사 자산(`style.css`·`data.js`·`map.js`·`app.js`) 4xx/5xx 0건, 타일·이미지 실패 0장.
  ⑨ 화면: 데스크톱 1919×992 `downloads/pokemoa-kakaomap-desktop.png`, 모바일 390×844 `downloads/pokemoa-kakaomap-mobile.png`(가로 넘침 0, 지도 330px, 범례 `bottom:28px`로 카카오 로고·저작권을 가리지 않음, 하단 탭바와 겹침 없음).

- **v3.9 GA4 확인 항목(2026-11-17 라이브 `https://moa-kr.github.io/pokemoa/`)**: `index.html`·`privacy.html`·`terms.html` 모두 `<head>` 상단에서 `gtag/js?id=G-LWRMBRD0X9` 로드(`typeof gtag === "function"`), `dataLayer`에 `js`·`config`와 `tab_view` 적재, `google-analytics.com/g/collect` 요청에 `tid=G-LWRMBRD0X9`·`en=page_view`로 실제 전송(3페이지 모두). 탭 전환(initial/switch)·반경 20km 변경·도감 세트 선택(m5)·도감/FAQ 더보기·정가 구매처(SSG) 링크 클릭·쿠팡 파트너스 카드 클릭·중계 연결 실패(`status:"error"`)까지 `trackEvent` 8종이 `dataLayer`에 그대로 쌓이는 것을 실제 브라우저 세션에서 확인. `window.gtag`를 지우고 탭을 바꿔도 화면은 그대로 동작(스니펫 차단·미리보기 환경에서도 안전). 자사 자산 4xx/5xx 0건, 페이지 오류 없음(Overpass API 504는 이 환경 네트워크 제한으로 기존과 같음).

- Playwright(Chromium)로 배포 URL(https://moa-kr.github.io/pokemoa/)에 실제 접속해
  데스크톱 1280×900, 모바일 390×844에서 확인
- **v3.8 확인 항목(2026-11-17 라이브)**: ① 로컬 `node relay/server.js` 문법 검사·`/health` 200 응답(`{ok, service:"pokemoa-relay", version:"1.0"}`), `OPTIONS /api/nearby` → 204 + `access-control-allow-origin: *`, `POST` → 405(조회 전용), 잘못된 lat → 400. ② 업체 응답을 흉내낸 스텁으로 점포·상품·수량 파싱, 체인 1곳이 403 HTML을 돌려줘도 나머지는 정상(`Promise.allSettled` 격리), 세븐일레븐은 키 미설정 시 `status:"error"`로 격리 — 23/23 통과(`tmp/pokemoa-relay-test/stub-test.js`). ③ `PokeMoaMap.applyRelay` 병합 로직(새 매장 추가·같은 자리 OSM 매장에 실제 재고 덮어쓰기·해제 시 원상복구·중복 없음·`out_of_stock`→`없음`) 19/19 통과. ④ 라이브 모바일 390×844(`downloads/pokemoa-v38-relay-ui.png`, `pokemoa-v38-relay-bar.png`): 상단 `실시간 중계` 바·`중계 연결` 버튼·연결 모달(Termux·cloudflared 안내 3단계) 정상 노출, 닫기/열기 동작. ⑤ `?relay=https://relay-demo.invalid` 자동 연결 시도 → `중계 응답 없음 · relay-demo.invalid · 제보·샘플 재고로 표시`로 폴백하고 지도·목록은 그대로(실패한 주소는 저장하지 않음). ⑥ `https://raw.githubusercontent.com/moa-kr/pokemoa/main/relay/server.js` 200 · 24,183바이트(로컬 파일과 동일).
- **실측 한계(2026-11-17)**: 이 작업을 한 데이터센터 회선에서는 이마트24 `everse` 403(WAF), 세븐일레븐 403(Incapsula), CU는 200이지만 `/api/store`의 점포별 `stock`이 `null`이라 실재고 0곳이었습니다. 집 회선(태블릿)에서의 결과는 `curl 'http://127.0.0.1:3100/api/nearby?lat=36.0733&lng=129.3947'`의 `sources`로 바로 확인할 수 있습니다.
- v3 확인 항목: 전국 17개 시·도 · 55개 지역 2단 셀렉트와 동네 검색(제주·해운대)·기본 지역 포항 북구, 지역 변경 시 지도 중심 이동과 재조회, 포항 북구 20km 활성(반경 20000 · `out center 100` 쿼리), 제주시 20km 유지(allow20), 서울 강남 자동 5km 전환 + 20km 비활성·`도심은 5km까지 지원` 안내, 로딩 스피너·진행 바, 목록 10곳+더보기(18곳→접힘), 마커 카드·브랜드 필터(CU 6곳), 지난 일정 접기(`지난 일정 보기 (6건)`)·캘린더 토글, 모바일 390px 가로 넘침 없음, 페이지 에러 0건
- v3.2 확인 항목(2026-11-17 라이브 `https://moa-kr.github.io/pokemoa/`): 지도 제목 `내 주변 편의점 4사, 어떤 카드가 있는지 한눈에`, 라이트(저채도) 타일 렌더링(워터마크 없음), 둥근 핀 0개 → 말풍선 마커 18개(`CU · 입고 3종`/`GS · 입고 3종`/`확인`/`없음`), 편의점 4사별 현황 바 5장(전체 18곳·재고 6·확인 9·없음 3 / GS25 6곳·재고 3 / CU 6곳·재고 2 / 세븐일레븐 5곳·재고 1 / 이마트24 1곳·재고 없음), `카드` 필터 줄·브랜드 칩 줄 제거(productRow=false), 정렬 드롭다운 기본값 `재고 우선`, `재고 있는 매장만` 토글 → 6곳·말풍선 6개로 동기 축소, CU 카드 클릭 → 6곳, 필터 초기화 복원, 20km 선택 시 클러스터 `18곳 · 재고 6` 1개로 묶임(확대하면 말풍선), 서울 강남 자동 5km·20km 비활성·`도심은 5km까지 지원`(21곳), 목록 10곳 → `더보기 (8개 더 보기)` → 18곳 → 접기, 지난 일정 접기·도감 34장·탭 전환 후 지도 복귀까지 정상, 모바일 390px 가로 넘침 0·상품 칩 11px, 페이지 오류 0건(콘솔·요청 실패 0건, Overpass 502는 이 환경 네트워크 제한)
- **v3.3 확인 항목(2026-11-17 라이브 `https://moa-kr.github.io/pokemoa/#guide`)**:
  세트 칩 9종(30th CELEBRATION·어비스아이·블랙볼트·로켓단의 영광·열풍의 아레나·배틀 파트너즈·테라스탈 페스타 ex·초전 브레이커·스타터 세트) 렌더링,
  세트를 고르면 요약(발매일·구성·정가·수록 카드·KREAM 즉시구매)·비교표·계산기 기준 정가·카드 도감·레어도 칩이 함께 전환 —
  m6a 4행(정가 70,000 + SSG 73,000 +4% + KREAM 슈링크 76,000 +9% + 논슈링크 72,000 +3%)·34장,
  M5 45,000 → KREAM 42,000(−7%)·10장, SV11B 40,000 → 43,000(+8%)·10장, SV10 30,000 → 41,000(+37%)·10장,
  SV9a 30,000 → 33,000(+10%)·10장, SV9 30,000 → 34,000(+13%)·11장, SV8a 50,000 → 67,000(+34%)·14장,
  SV8 30,000 → 41,000(+37%)·9장, 스타터 세트 17,000 → 20,000(+18%)·12장(`세트 가격/세트당 단가`로 전환),
  같은 입력값 41,000원이 SV10에서는 `+36.7%`·+11,000원, m6a로 바꾸면 `−41.4%`·−29,000원으로 재계산(기준 정가 자동 전환),
  레어도 칩은 세트별 실제 값만 생성(SV8a `SAR·UR`, SV10 `SAR·UR·RR`, M5 `MUR·SAR·SR` 등), 카드 클릭 모달(SV8a 블래키 ex SAR 217/187) 정상,
  홈 인기 카드팩 카드 클릭 → 해당 세트 도감으로 이동(블랙볼트 확인), 로고·파비콘 교체(헤더 마크 rect 4개 · `#ffcb05` · 네이비 라운드 스퀘어 `#101f3c`),
  모바일 390px 가로 넘침 0 · 세트 칩 가로 스크롤 · 인트로 문단 노출 · 세트 전환 정상, 페이지 오류 0건
- **v3.4 확인 항목(2026-11-17 라이브 `https://moa-kr.github.io/pokemoa/#guide`)**: 제휴 상품 이미지 `assets/coupang-supplies.jpg` 200(55.9KB · 480×480)로 로드(`naturalWidth` 480, 실패 요청 0건), 이미지·CTA 두 링크 모두 `https://link.coupang.com/a/iKC6PvZjtQ`(`target="_blank"` · `rel="noopener noreferrer sponsored"`), 클릭하면 새 탭으로 쿠팡 상품 페이지(상품번호 9732320873 · 탑로더+슬리브 세트)로 이동 — `app.js`가 `http(s)` 링크는 토스트로 막지 않으며 `coupang-30th` 자리(플레이스홀더)는 기존 토스트 유지,
  카드 하단에 대가성 문구 노출, 데스크톱 1280×900 · 모바일 390×844 가로 넘침 0, 페이지 오류 0건
  (단, 이 환경의 헤드리스 크롬에서 상품 페이지 자체는 쿠팡 봇 차단 `Access Denied`가 뜹니다 — 일반 브라우저·한국 IP에서는 정상)
- **v3.5 확인 항목(2026-11-17 라이브 `https://moa-kr.github.io/pokemoa/#guide`)**: 제휴 상품 카드 본문에서 가격·할인 문구가 사라지고 `개봉한 카드를 바로 넣어 보관하는 3×4인치 탑로더와 슬리브 세트입니다. 최신 가격과 배송 조건은 쿠팡 상품 페이지에서 확인해 주세요.`만 남음(본문에 `원`·`정가`·`쿠폰`·`2026-11-17` 표기 없음), 이미지 `assets/coupang-supplies.jpg` 정상 로드, 이미지·CTA 링크 `https://link.coupang.com/a/iKC6PvZjtQ`(`target="_blank"` · `rel="noopener noreferrer sponsored"`) 유지, 대가성 문구 유지, 데스크톱 1280×900 · 모바일 390×844 가로 넘침 0, 페이지 오류 0건
- **v3.6 확인 항목(2026-11-17 라이브 `https://moa-kr.github.io/pokemoa/#guide`)**:
  도감 `수록 카드와 레어도` 첫 화면이 **4장**(`#dexGrid .dex-card` 4)이고 바로 아래에 `더보기 (30장 더 보기)` 노출(전체 34장),
  버튼 클릭 → **34장 + `접기`**(`aria-expanded="true"`), 다시 클릭 → 4장으로 복귀,
  세트 칩 `테라스탈 페스타 ex` 전환 → 다시 **4장** + `더보기 (10장 더 보기)`(전체 14장)로 리셋, 30th 복귀 정상,
  검색·레어도 필터로 결과가 4장 이하가 되면 버튼 `hidden`(버튼 숨김),
  제휴 슬롯은 `<iframe src="https://coupa.ng/cq5BV0" width="120" height="240" scrolling="no" referrerpolicy="unsafe-url">` — 실측 120×240, 내부에 `partners.coupangcdn.com` 위젯이 로드되어
  상품 이미지(212px)·상품명(`포켓몬 카드 탑로더 + 슬리브 세트 50개, 1세트, 클리어`)·`쇼핑하기` 링크가 뜨고, 카드 안에 `원·정가·할인·쿠폰` 문자열 0건,
  상단 `쿠팡 파트너스`·`제휴 상품` 라벨과 하단 대가성 문구 유지,
  데스크톱 1280×900 `scrollWidth 1280`, 모바일 390×844 `scrollWidth 390`(가로 넘침 0)에서 모두 iframe 120×240 로드, 페이지 오류·실패 요청 0건
- **v3.7 확인 항목(2026-11-17 라이브 `https://moa-kr.github.io/pokemoa/#guide`)**:
  FAQ 첫 화면이 **3문항**만 보이고(`.faq-item` 표시 3 / 전체 8) 바로 아래 `더보기 (5개 더 보기)` 노출 → 클릭 시 **8문항 + `접기`**(`aria-expanded="true"`) → 다시 클릭하면 3문항 복귀(펼쳐 둔 답변은 닫힘),
  도감·가이드 제휴 카드의 위젯 행은 **폭 316px · `gap:12px` · `flex-wrap:nowrap` · `justify-content:center`**, 슬롯 2개 x=69·201(각 120×240), iframe `https://coupa.ng/cq5BV0` · `https://coupa.ng/cq5DGN` 실측 120×240,
  두 iframe 안에 `partners.coupangcdn.com` 위젯이 로드되어 상품 1 `포켓몬 카드 탑로더 + 슬리브 세트 50개, 1세트, 클리어`, 상품 2 `BERYFAM 35PT 자석 카드 케이스 고투명 UV 차단 포켓몬 원피스 TCG 스포츠카드`와 각 `쇼핑하기` 링크가 뜸,
  카드 상단 `쿠팡 파트너스`·`제휴 상품` 라벨과 하단 대가성 문구 유지, 카드 안에 `원·정가·할인·쿠폰` 문자열 0건,
  「정가 구매처」(`#stores`) 중간 제휴 카드도 같은 구성 — 기존 `data-affiliate="coupang-30th"` 플레이스홀더·`쿠팡에서 시세 보기` 토스트 버튼 **DOM 0건**, 위젯 행 폭 316px·슬롯 2개(x=69·201), 두 위젯 모두 로드,
  가로 넘침 0(모바일 390×844 `scrollWidth 390` / 데스크톱 1440 `scrollWidth 1440` / 로컬 320px `scrollWidth 320`), 페이지 오류·실패 요청 0건
- 스크린샷(v3.7): `screenshots/42-v37-faq-3-mobile.png`(FAQ 3문항), `43-v37-faq-3-expanded-mobile.png`(펼침),
  `44-v37-coupang-2col-guide-mobile.png`(도감·가이드 2열), `45-v37-coupang-2col-stores-mobile.png`(정가 구매처 2열),
  `46-v37-faq-3-desktop.png`, `47-v37-coupang-2col-desktop.png`
  (라이브 캡처: `downloads/pokemoa-v37-mobile.png` — 모바일 390×844 FAQ + 두 제휴 카드)
- 스크린샷(v3.6): `screenshots/39-v36-dex-4cards-desktop.png`(4장 접힘), `40-v36-coupang-widget-desktop.png`(파트너스 위젯),
  `41-v36-mobile-live.png`(모바일 2패널)
  (라이브 캡처: `downloads/pokemoa-v36-mobile.png` — 모바일 390×844 두 화면을 나란히 묶은 파일)
- 스크린샷(v3.4): `screenshots/35-coupang-supplies-desktop.png`(카드), `36-coupang-supplies-context-desktop.png`, `37-coupang-supplies-mobile.png`, `38-coupang-live-desktop.png`
  (라이브 캡처: `downloads/pokemoa-coupang-banner.png`, `downloads/pokemoa-coupang-banner-mobile.png`)
- 스크린샷(v3.3): 라이브 캡처 `downloads/pokemoa-multiset-guide.png`(테라스탈 페스타 ex 도감·가이드),
  `downloads/pokemoa-multiset-mobile.png`·`pokemoa-multiset-mobile-dex.png`(모바일 390px), `downloads/pokemoa-header-logo.png`(새 로고)
- 스크린샷(v3.2): `screenshots/30-v32-desktop.png`(요약 바·라이트 지도·말풍선),
  `31-v32-map-popup.png`(매장 팝업 보유 카드), `32-v32-stock-only.png`(재고 있는 매장만),
  `33-v32-20km-cluster.png`(20km 클러스터), `34-v32-mobile.png`(모바일 390px)
  (배포 화면 라이브 캡처: `downloads/pokemoa-v32-pokeconv-style.png`, `pokemoa-v32-mobile.png`)
- v3.1 확인 항목(2026-11-17 라이브): 지도 제목·부제가 `내 주변 편의점 4사, 실제 지도에서 찾기`로 바뀌고 본문에 4사 외 업종 언급이 없음, 브랜드 칩 5종(전체·GS25·CU·세븐일레븐·이마트24), 카드 상품 칩 7종(전체 카드·30th CELEBRATION·배틀 파트너즈·테라스탈 페스타 ex·로켓단의 영광·초전 브레이커·스타터 세트), 매장 목록·지도 카드의 상품명 태그(입고/소량/확인 필요/품절/미입고 + `최근 입고 품절` 머리표), `30th CELEBRATION` 필터 선택 시 22곳으로 축소(미입고 2곳 제외)·마커 동기화, CU 필터 12곳, 필터 초기화 복원, 10곳+더보기(31곳→10곳), 서울 강남 자동 5km 전환과 `도심은 5km까지 지원`, 모바일 390px 가로 넘침 0·태그 10.5px, 페이지 오류 0건(콘솔의 502는 Overpass 응답)
- v3.1 스냅샷: Overpass 스냅샷에서 4사 외 항목 285건을 제거해 **1,272건 → 987건**(전국 55개 지역 유지)
- v3 Overpass 상태(2026-11-17 라이브 확인)
  - 실시간 응답: `실시간 조회 · OpenStreetMap 주변 매장 31곳 (Overpass API)` — 포항 북구 3km, 마커 31개·목록 10+더보기 21
  - 20km 실시간: 포항 북구 **97곳**(`out center 100` · 확대 10), 제주시 **87곳**
  - 도심 5km 실시간: 서울 강남 반경 5km에서 1,045곳 응답 중 가까운 **90곳** 표시(마커 상한)
  - 8초 초과: 내장 스냅샷 18곳을 먼저 표시(`조금 더 기다리는 중`) → 응답 도착 시 31곳으로 자동 교체(실제로 확인)
  - 502·타임아웃: `실시간 조회 지연/제한 → 내장 실제 좌표 스냅샷(반경 3km) 사용 (2026-11-17)` 배지 + `실시간 다시 조회` 버튼. 20km를 고른 상태면 `· 넓은 반경은 실시간 조회에서만 표시`를 덧붙입니다. 검증 시점에 overpass-api.de가 용량 초과로 간헐적 502를 반환해 스냅샷 경로가 자주 쓰였습니다
- 스크린샷(v3.1): `screenshots/26-v31-desktop-stores.png`(매장 목록 카드명), `27-v31-map-card.png`(지도 팝업 카드명),
  `28-v31-product-filter.png`(30th CELEBRATION 필터), `29-v31-mobile.png`
  (배포 화면 라이브 캡처: `downloads/pokemoa-v31-stores.png`, `pokemoa-v31-card.png`, `pokemoa-v31-filter.png`, `pokemoa-v31-mobile.png`)
- 스크린샷(v3): `screenshots/18-nationwide-loading.png`(로딩), `19-nationwide-desktop.png`, `20-pohang-20km.png`,
  `21-region-search.png`(동네 검색), `22-jeju-20km.png`, `23-seoul-5km.png`(도심 20km 비활성),
  `24-mobile-nationwide.png`, `25-live-pohang.png`
  (배포 화면 라이브 캡처: `downloads/pokemoa-v3-nationwide.png`, `pokemoa-v3-pohang-20km.png`, `pokemoa-v3-jeju-20km.png`, `pokemoa-v3-seoul-5km.png`, `pokemoa-v3-loading.png`)
- 스크린샷(v2.1 이전): `screenshots/01-pricing-desktop.png`, `02-map-desktop.png`, `03-map-loading-desktop.png`,
  `04-card-mobile.png`, `05-mobile-map.png`, `06-mobile-store-list.png`, `07-mobile-pricing.png`, `08-cards-guide.png`,
  `10-store-list-10-more.png`, `11-store-list-expanded.png`, `12-radius-20km.png`, `13-seoul-5km-note.png`,
  `14-schedule-folded.png`, `15-schedule-past-open.png`, `16-channels-links.png`, `17-mobile-schedule.png`
- v2.1 확인 항목: 하단 내비 `동네에서 찾기`, 목록 10곳+더보기(펼침/접힘·필터 초기화), 20km 활성/비활성과 자동 5km 전환, `out center 100` 쿼리, 지난 일정 접기·캘린더 토글, 채널 링크 7종
- v2 확인 항목: 첫 화면이 「동네에서 찾기」인지, OSM 타일(`tile.openstreetmap.org`) 로드, 로딩 스피너·진행 바·스켈레톤 노출,
  배지의 조회 상태 표기, 지역 변경(포항 북구→부산 서면), 브랜드 필터(CU 6곳)·반경 필터(1/3/5km), 마커 선택 카드,
  내 위치(권한 허용·차단 양쪽), 2번 탭 「정가 구매처」, 지도 탭 왕복 후 지도 크기, 모바일 하단 내비 순서·가로 넘침 없음
- Overpass 응답 세 가지 경로(실시간 / 8초 지연 후 교체 / 502·타임아웃 스냅샷) 모두 위 v3 항목에서 다시 확인
- 페이지 에러 0건. 콘솔에는 Overpass가 돌려준 502 응답 오류만 남고(외부 API 상태), 스크립트 오류는 없습니다.
- 스크린샷(v2 이전): `screenshots/02-map-desktop.png`, `03-map-loading-desktop.png`,
  `04-card-mobile.png`, `05-mobile-map.png`, `06-mobile-store-list.png`, `07-mobile-pricing.png`,
  `10-store-list-10-more.png`, `11-store-list-expanded.png`, `12-radius-20km.png`,
  `13-seoul-5km-note.png`, `14-schedule-folded.png`, `15-schedule-past-open.png`, `16-channels-links.png`
  (배포 화면 라이브 캡처: `downloads/pokemoa-v2-live-map.png`, `downloads/pokemoa-v2-live-stores.png`)

## 7. 참고 자료

- 포켓몬 카드 게임 공식 제품 정보 — https://pokemoncard.co.kr/card/960
- 포켓몬스토어 30주년 특설 페이지 — https://www.pokemonstore.co.kr/pages/pokemoncardgame30th/product/index.html
- SSG 공식인증샵 상품 페이지 — https://www.ssg.com/item/itemView.ssg?itemId=1000881834004
- 30th Celebration 카드 목록(176종) — https://www.tcgheart.com/set/30th-celebration-korean
- 편의점 판매 일정 보도 — https://tcgnews.kr/article/34
- KREAM 시세(미개봉 1박스 · 한글판) — https://kream.co.kr/products/1072895 (슈링크) · https://kream.co.kr/products/1094196 (논슈링크)

포켓몬카드모아는 포켓몬코리아 및 권리자와 무관한 비공식 정보 사이트입니다.
